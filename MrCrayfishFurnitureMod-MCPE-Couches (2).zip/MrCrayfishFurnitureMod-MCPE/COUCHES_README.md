# Sofas y mesas de centro para MrCrayfish's Furniture Mod PE

Se añadieron 5 sofas (blanco, verde, cafe, rojo y negro) y 2 mesas de centro (madera y piedra).
Mesa de centro: bloques 208 (madera) y 209 (piedra), items 468 y 469; se unen entre si y las patas
solo aparecen en las esquinas libres (logica en CoffeeTableLogic.h, probada contra el JS).
Aparecen en el inventario creativo. Se orientan segun donde miras y se unen entre si
(esquinas y brazos), igual que en el script .js.

## Archivos nuevos
- jni/Furniture/world/tile/CouchTile.h/.cpp   (bloque, ids 211-215)
- jni/Furniture/world/item/CouchItem.h/.cpp   (items, ids 471-475)
- jni/Furniture/render/tile/CouchLogic.h      (logica de conexion, probada contra el JS)
- jni/Furniture/render/tile/renderers/CouchRenderer.h/.cpp

## Archivos modificados
- jni/Furniture_hooks.cpp (registro de tiles, items, renderers, nombres, creativo)
- jni/Furniture/world/tile/FurnitureTile.h/.cpp, jni/Furniture/world/item/FurnitureItem.h/.cpp
- jni/MCPE/world/entity/Motive.h  (faltaba declarar initCustomMotives(), error del proyecto original)
- assets/images/items.meta y items-opaque.png (5 iconos nuevos)

## Compilar (necesita Android NDK y Android SDK)
    cd MrCrayfishFurnitureMod-MCPE
    ndk-build            # genera libs/armeabi-v7a/libcom.mrcrayfish.furniturepe.so
    ant debug            # o empaquetalo con tu herramienta habitual (build.xml incluido)
Instala el APK resultante y activalo en BlockLauncher > Administrar addons.
Ojo: el AndroidManifest apunta a MCPE 0.11.0.

## Compilar sin PC (GitHub Actions)
Se incluye .github/workflows/build.yml. Sube el proyecto a un repositorio de GitHub,
ve a Actions > "Build addon APK" > Run workflow, y descarga el APK desde "Artifacts".
(Usa el NDK r10e. No se pudo probar el workflow al prepararlo.)
