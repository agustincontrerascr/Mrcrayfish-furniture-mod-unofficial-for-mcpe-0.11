#pragma once

#include "FurnitureTile.h"
#include "attributes/FurnitureTileAttributes.h"

class CoffeeTableTile : public FurnitureTile {
public:
	static int _woodId;
	static int _stoneId;

	// useSecondary: usar la textura secundaria (cobblestone) en vez de la primaria
	CoffeeTableTile(int, std::string, FurnitureTileAttributes, int, bool);

	virtual const TextureUVCoordinateSet& getTexture(signed char, int);
	virtual int getResource(int, Random*);
	virtual bool use(Player*, int, int, int);
	virtual void addAABBs(TileSource*, int, int, int, AABB const*, std::vector<AABB, std::allocator<AABB>>&);

private:
	int droppedItem;
};
