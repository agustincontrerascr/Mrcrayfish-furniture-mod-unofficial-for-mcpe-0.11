#pragma once

#include "MCPE/world/item/TileItem.h"
#include "MCPE/world/level/tile/Tile.h"
#include "MCPE/world/level/TileSource.h"

#include "../../util/CollisionHelper.h"

class FurnitureTile : public Tile {
public:
	static FurnitureTile* tileTableWood;
	static FurnitureTile* tileTableStone;
	static FurnitureTile* tileChairWood;
	static FurnitureTile* tileChairStone;
	static FurnitureTile* tileToilet;
	static FurnitureTile* tileCabinet;
	static FurnitureTile* tileDoorbell;
	static FurnitureTile* tileBin;
	static FurnitureTile* tileLamp;
	static FurnitureTile* tileCoffeeTableWood;
	static FurnitureTile* tileCoffeeTableStone;
	static FurnitureTile* tileWhiteCouch;
	static FurnitureTile* tileGreenCouch;
	static FurnitureTile* tileBrownCouch;
	static FurnitureTile* tileRedCouch;
	static FurnitureTile* tileBlackCouch;
	
	FurnitureTile(int, Material const*);
};
