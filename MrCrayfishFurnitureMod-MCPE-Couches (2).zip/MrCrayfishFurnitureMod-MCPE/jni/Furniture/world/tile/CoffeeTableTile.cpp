#include "CoffeeTableTile.h"

int CoffeeTableTile::_woodId = 208;
int CoffeeTableTile::_stoneId = 209;

CoffeeTableTile::CoffeeTableTile(int id, std::string name, FurnitureTileAttributes attributes, int item, bool useSecondary) : FurnitureTile(id, attributes.realMaterial) {
	Tile::solid[id] = false;
	Tile::lightBlock[id] = 0;

	setNameId(name);
	setSoundType(attributes.sounds);
	setDestroyTime(attributes.hardness);
	tex = useSecondary ? attributes.secondary_tex : attributes.primary_tex;
	droppedItem = item;
}

const TextureUVCoordinateSet& CoffeeTableTile::getTexture(signed char side, int data) {
	return tex;
}

bool CoffeeTableTile::use(Player* player, int x, int y, int z) {
	return false;
}

int CoffeeTableTile::getResource(int data, Random* rand) {
	return droppedItem;
}

void CoffeeTableTile::addAABBs(TileSource* region, int x, int y, int z, AABB const* posAABB, std::vector<AABB, std::allocator<AABB>>& pool) {
	addAABB(AABB(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F).move(x, y, z), posAABB, pool);
}
