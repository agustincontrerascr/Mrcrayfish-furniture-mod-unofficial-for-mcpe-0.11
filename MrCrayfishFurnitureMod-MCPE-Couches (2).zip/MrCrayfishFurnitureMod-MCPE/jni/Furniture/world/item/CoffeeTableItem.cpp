#include "CoffeeTableItem.h"

int CoffeeTableItem::_woodId = 468;
int CoffeeTableItem::_stoneId = 469;

CoffeeTableItem::CoffeeTableItem(int id, std::string name, int tileId) : PlaceableItem(id, tileId) {
	setNameID(name);
	setIcon(name, 0);
}
