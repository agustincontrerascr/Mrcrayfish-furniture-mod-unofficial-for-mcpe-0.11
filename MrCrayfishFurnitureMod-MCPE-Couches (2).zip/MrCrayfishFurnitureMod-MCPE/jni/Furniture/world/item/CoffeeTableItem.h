#pragma once

#include "PlaceableItem.h"

class CoffeeTableItem : public PlaceableItem {
public:
	static int _woodId;
	static int _stoneId;

	CoffeeTableItem(int, std::string, int);
};
