#include "CoffeeTableRenderer.h"

#include "../CoffeeTableLogic.h"
#include "../../../world/tile/CoffeeTableTile.h"

static bool isCoffeeTable(int id) {
	return id == CoffeeTableTile::_woodId || id == CoffeeTableTile::_stoneId;
}

void CoffeeTableRenderer::render(const TilePos& pos, FurnitureTile* tile, TileTessellator* tess) {
	int x = pos.x, y = pos.y, z = pos.z;

	bool forward = isCoffeeTable(tess->region->getTile(x + 1, y, z).id);
	bool back = isCoffeeTable(tess->region->getTile(x - 1, y, z).id);
	bool left = isCoffeeTable(tess->region->getTile(x, y, z - 1).id);
	bool right = isCoffeeTable(tess->region->getTile(x, y, z + 1).id);

	CouchBox boxes[8];
	int count = CoffeeTableLogic::computeBoxes(forward, back, left, right, boxes);

	tess->useForcedUV = true;
	tess->forcedUV = tile->getTexture(0, 0);

	for(int i = 0; i < count; i++) {
		tess->setRenderBounds(boxes[i].x1, boxes[i].y1, boxes[i].z1, boxes[i].x2, boxes[i].y2, boxes[i].z2);
		tess->tessellateBlockInWorld(tile, pos);
	}

	tess->useForcedUV = false;
}
