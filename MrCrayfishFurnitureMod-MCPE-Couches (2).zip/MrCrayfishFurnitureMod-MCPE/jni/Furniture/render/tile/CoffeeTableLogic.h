#pragma once

// Logica pura de las patas de la mesa de centro (port de renderCoffeeTable del .js).
// Una pata solo aparece en una esquina si no hay otra mesa de centro pegada a esa esquina.

#include "CouchLogic.h" // para CouchBox

namespace CoffeeTableLogic {

// forward = x+1, back = x-1, left = z-1, right = z+1
inline int computeBoxes(bool forward, bool back, bool left, bool right, CouchBox* out) {
	int n = 0;
	out[n++] = CouchBox{0.0f, 0.4f, 0.0f, 1.0f, 0.5f, 1.0f}; // tapa
	if(!back && !left)    out[n++] = CouchBox{0.0f, 0.0f, 0.0f, 0.1f, 0.4f, 0.1f};
	if(!back && !right)   out[n++] = CouchBox{0.0f, 0.0f, 0.9f, 0.1f, 0.4f, 1.0f};
	if(!forward && !left) out[n++] = CouchBox{0.9f, 0.0f, 0.0f, 1.0f, 0.4f, 0.1f};
	if(!forward && !right)out[n++] = CouchBox{0.9f, 0.0f, 0.9f, 1.0f, 0.4f, 1.0f};
	return n;
}

}
