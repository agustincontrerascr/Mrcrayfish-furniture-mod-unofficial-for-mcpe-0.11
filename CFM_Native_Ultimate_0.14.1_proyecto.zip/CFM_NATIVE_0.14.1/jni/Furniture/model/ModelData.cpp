#include "ModelData.h"
static const ModelBox BOXES_aquarium[] = {
	{0.0625f,0.0f,0.0625f,0.9375f,0.0187f,0.9375f,0,true},
	{0.9375f,0.0f,0.0625f,1.0f,0.0187f,0.9375f,1,true},
	{0.0f,0.0f,0.0625f,0.0625f,0.0187f,0.9375f,1,true},
	{0.0625f,0.0f,0.0f,0.9375f,0.0187f,0.0625f,1,true},
	{0.0625f,0.0f,0.9375f,0.9375f,0.0187f,1.0f,1,true},
	{0.0f,0.0f,0.0f,0.0625f,0.625f,0.0625f,0,true},
	{0.9375f,0.0f,0.0f,1.0f,0.625f,0.0625f,0,true},
	{0.9375f,0.0f,0.9375f,1.0f,0.625f,1.0f,0,true},
	{0.0f,0.0f,0.9375f,0.0625f,0.625f,1.0f,0,true},
	{0.0625f,0.6062f,0.0625f,0.9375f,0.625f,0.9375f,1,true},
	{0.9375f,0.6062f,0.0625f,1.0f,0.625f,0.9375f,1,true},
	{0.0f,0.6062f,0.0625f,0.0625f,0.625f,0.9375f,1,true},
	{0.0625f,0.6062f,0.0f,0.9375f,0.625f,0.0625f,1,true},
	{0.0625f,0.6062f,0.9375f,0.9375f,0.625f,1.0f,1,true},
	{0.0625f,0.0f,0.0625f,0.9375f,0.25f,0.9375f,2,true},
	{0.0625f,0.0187f,0.0063f,0.9375f,0.6062f,0.9938f,3,true},
	{0.0063f,0.0f,0.0625f,0.9938f,0.6062f,0.9375f,3,true}
};
static const ModelBox BOXES_canvas[] = {
	{0.25f,-0.125f,0.125f,0.3125f,1.0f,0.1875f,0,true},
	{0.6875f,-0.125f,0.125f,0.75f,1.0f,0.1875f,0,true},
	{0.0625f,0.6687f,0.4375f,0.9375f,0.6875f,0.575f,1,true},
	{0.0625f,0.6875f,0.4375f,0.9375f,1.5f,0.45f,1,true}
};
static const ModelBox BOXES_chimney[] = {
	{0.75f,0.0f,-0.0063f,1.0f,0.4375f,0.8131f,0,true},
	{0.6875f,0.25f,-0.0006f,0.9375f,0.5f,0.8125f,0,true},
	{0.0625f,0.25f,-0.0006f,0.3125f,0.5f,0.8125f,0,true},
	{0.0938f,0.0f,0.0f,0.9062f,0.625f,0.0625f,0,true},
	{0.0938f,0.5625f,-0.0003f,0.9062f,0.75f,0.75f,0,true},
	{0.2812f,0.75f,0.0f,0.7188f,1.4375f,0.25f,0,true},
	{0.375f,0.0f,0.25f,0.875f,0.25f,0.5f,1,true},
	{0.1875f,0.1875f,0.0f,0.6875f,0.4375f,0.25f,1,true},
	{0.875f,0.0f,0.8125f,0.9375f,0.4375f,0.8812f,2,true},
	{0.0625f,0.0f,0.8125f,0.125f,0.4375f,0.8812f,2,true},
	{0.25f,0.0f,0.8125f,0.3125f,0.4375f,0.8812f,2,true},
	{0.4375f,0.0f,0.8125f,0.5f,0.4375f,0.8812f,2,true},
	{0.6875f,0.0f,0.8125f,0.75f,0.4375f,0.8812f,2,true},
	{0.5f,0.0f,0.8125f,0.5625f,0.4375f,0.8812f,2,true},
	{0.0f,0.1875f,0.8125f,1.0f,0.25f,0.875f,2,true},
	{0.0f,0.3125f,0.8125f,1.0f,0.375f,0.875f,2,true},
	{0.0f,0.0f,-0.0063f,0.25f,0.4375f,0.8131f,0,true},
	{0.2819f,1.4375f,0.375f,0.7181f,1.5f,0.625f,0,true},
	{0.25f,0.0f,0.0625f,0.75f,0.0625f,0.8125f,0,true},
	{0.25f,0.0375f,0.5625f,0.75f,0.35f,0.625f,2,true}
};
static const ModelBox BOXES_spiral_stairs[] = {
	{-0.125f,0.0f,0.875f,0.125f,0.9999f,1.125f,0,true},
	{0.125f,0.0f,0.8125f,1.0f,0.125f,1.0625f,1,true},
	{-0.0625f,0.25f,0.5625f,0.9375f,0.375f,0.8125f,1,true},
	{0.0625f,0.5f,0.6875f,1.0625f,0.625f,0.9375f,1,true},
	{0.0938f,0.75f,0.0625f,0.3438f,0.875f,1.0625f,1,true}
};
static const ModelBox BOXES_bear_rug[] = {
	{0.625f,0.1875f,1.0f,0.75f,0.3125f,1.125f,0,true},
	{0.25f,0.1875f,1.0f,0.375f,0.3125f,1.125f,0,true},
	{0.4375f,0.0625f,1.1875f,0.5625f,0.1875f,1.25f,1,true},
	{0.375f,0.1875f,1.1938f,0.4375f,0.25f,1.1938f,0,true},
	{0.5625f,0.1875f,1.1938f,0.625f,0.25f,1.1938f,0,true},
	{0.125f,0.0f,0.0625f,0.875f,0.125f,0.9375f,0,true},
	{0.875f,0.0f,0.5625f,1.1875f,0.0625f,0.8125f,0,true},
	{-0.1875f,0.0f,0.5625f,0.125f,0.0625f,0.8125f,0,true},
	{0.875f,0.0f,0.3312f,1.25f,0.0625f,0.5813f,0,true},
	{-0.25f,0.0f,0.3312f,0.125f,0.0625f,0.5813f,0,true},
	{0.3125f,0.0f,0.875f,0.6875f,0.25f,1.1875f,0,true}
};
static const ModelBox BOXES_black_board[] = {
	{0.0f,0.0f,0.0f,1.0f,0.0625f,0.5f,0,true},
	{0.0625f,0.0625f,0.0f,0.9375f,1.0f,0.0938f,1,true},
	{0.0f,0.0625f,0.0f,0.0625f,1.0f,0.125f,0,true},
	{0.9375f,0.0625f,0.0f,1.0f,1.0f,0.125f,0,true},
	{0.0f,1.0f,0.0f,1.0f,1.0625f,0.125f,0,true},
	{0.1875f,0.0625f,0.125f,0.25f,0.125f,0.25f,2,true},
	{0.4375f,0.0625f,0.25f,0.9375f,0.125f,0.3125f,1,true}
};
static const ModelBox BOXES_office_chair[] = {
	{0.0f,0.1875f,0.4062f,1.0f,0.375f,0.5938f,0,true},
	{0.0f,0.1875f,0.4062f,1.0f,0.375f,0.5938f,0,true},
	{0.125f,0.0f,0.125f,0.3125f,0.1875f,0.3125f,1,true},
	{0.125f,0.0f,0.6875f,0.3125f,0.1875f,0.875f,1,true},
	{0.6875f,0.0f,0.6875f,0.875f,0.1875f,0.875f,1,true},
	{0.6875f,0.0f,0.125f,0.875f,0.1875f,0.3125f,1,true},
	{0.4062f,0.1875f,0.4062f,0.5938f,0.625f,0.5938f,0,true},
	{0.125f,0.625f,0.25f,0.875f,0.75f,0.875f,1,true},
	{0.125f,0.625f,0.125f,0.875f,1.5f,0.25f,1,true},
	{0.0f,0.625f,0.125f,0.125f,0.75f,0.875f,0,true},
	{0.0f,0.75f,0.125f,0.125f,0.875f,0.25f,0,true},
	{0.0f,0.875f,0.125f,0.125f,1.0f,0.875f,0,true},
	{-0.0312f,1.0f,0.0938f,0.1562f,1.0312f,0.9062f,1,true},
	{0.875f,0.625f,0.125f,1.0f,0.75f,0.875f,0,true},
	{0.875f,0.75f,0.125f,1.0f,0.875f,0.25f,0,true},
	{0.875f,0.875f,0.125f,1.0f,1.0f,0.875f,0,true},
	{0.8438f,1.0f,0.0938f,1.0312f,1.0312f,0.9062f,1,true},
	{0.1875f,1.4375f,0.2188f,0.8125f,1.5f,0.2812f,1,true},
	{0.125f,1.625f,0.125f,0.875f,1.5f,0.25f,1,true}
};
static const ModelBox BOXES_wheelie_bin[] = {
	{0.1875f,0.0f,0.1875f,0.8125f,0.4375f,0.8125f,0,true},
	{0.125f,0.4375f,0.125f,0.875f,0.8125f,0.875f,0,true},
	{0.125f,0.0f,0.1875f,0.1875f,0.4375f,0.8125f,0,true},
	{0.0625f,0.4375f,0.125f,0.125f,0.8125f,0.875f,0,true},
	{0.8125f,0.0f,0.1875f,0.875f,0.4375f,0.8125f,0,true},
	{0.875f,0.4375f,0.125f,0.9375f,0.8125f,0.875f,0,true},
	{0.1875f,0.0f,0.8125f,0.8125f,0.4375f,0.875f,0,true},
	{0.1875f,0.0f,0.125f,0.8125f,0.4375f,0.1875f,0,true},
	{0.125f,0.4375f,0.0625f,0.875f,0.8125f,0.125f,0,true},
	{0.0f,0.8125f,0.0f,1.0f,0.875f,1.0f,1,true},
	{0.0625f,0.875f,0.125f,0.9375f,0.9375f,0.9375f,1,true},
	{0.1875f,0.9375f,0.1875f,0.8125f,1.0f,0.8125f,1,true},
	{0.0625f,-0.0625f,0.25f,0.125f,0.125f,0.4375f,2,true},
	{0.875f,-0.0625f,0.25f,0.9375f,0.125f,0.4375f,2,true},
	{0.125f,0.9375f,0.0625f,0.875f,1.0f,0.125f,0,true},
	{0.125f,0.4375f,0.875f,0.25f,0.8125f,0.9375f,0,true},
	{0.75f,0.4375f,0.875f,0.875f,0.8125f,0.9375f,0,true},
	{0.25f,0.6875f,0.875f,0.75f,0.8125f,0.9375f,0,true},
	{0.25f,0.4375f,0.875f,0.75f,0.5625f,0.9375f,0,true},
	{0.25f,0.5625f,0.875f,0.75f,0.6875f,0.9375f,3,true}
};
static const ModelBox BOXES_bottle[] = {
	{0.375f,0.0f,0.375f,0.6875f,0.0625f,0.6875f,0,true},
	{0.3125f,0.0625f,0.3125f,0.75f,0.125f,0.375f,0,true},
	{0.25f,0.125f,0.25f,0.8125f,0.1875f,0.3125f,0,true},
	{0.25f,0.1875f,0.1875f,0.8125f,0.4375f,0.25f,0,true},
	{0.25f,0.4375f,0.25f,0.3125f,0.5f,0.8125f,0,true},
	{0.3125f,0.5f,0.3125f,0.75f,0.5625f,0.375f,0,true},
	{0.3125f,0.0625f,0.3125f,0.375f,0.125f,0.75f,0,true},
	{0.6875f,0.0625f,0.3125f,0.75f,0.125f,0.75f,0,true},
	{0.3125f,0.0625f,0.6875f,0.75f,0.125f,0.75f,0,true},
	{0.25f,0.125f,0.75f,0.8125f,0.1875f,0.8125f,0,true},
	{0.25f,0.125f,0.3125f,0.3125f,0.1875f,0.75f,0,true},
	{0.75f,0.125f,0.3125f,0.8125f,0.1875f,0.75f,0,true},
	{0.25f,0.1875f,0.8086f,0.8125f,0.4375f,0.8711f,0,true},
	{0.1875f,0.1875f,0.25f,0.25f,0.4375f,0.8125f,0,true},
	{0.8125f,0.1875f,0.25f,0.875f,0.4375f,0.8125f,0,true},
	{0.25f,0.4375f,0.25f,0.8125f,0.5f,0.3125f,0,true},
	{0.25f,0.4375f,0.75f,0.8125f,0.5f,0.8125f,0,true},
	{0.75f,0.4375f,0.25f,0.8125f,0.5f,0.8125f,0,true},
	{0.25f,0.4375f,0.25f,0.3125f,0.5f,0.8125f,0,true},
	{0.3125f,0.5f,0.6875f,0.75f,0.5625f,0.75f,0,true},
	{0.3125f,0.5f,0.375f,0.375f,0.5625f,0.6875f,0,true},
	{0.3125f,0.5f,0.3125f,0.75f,0.5625f,0.375f,0,true},
	{0.6875f,0.5f,0.375f,0.75f,0.5625f,0.6875f,0,true},
	{0.375f,0.5625f,0.375f,0.6875f,0.8125f,0.4375f,0,true},
	{0.375f,0.5625f,0.625f,0.6875f,0.8125f,0.6875f,0,true},
	{0.375f,0.5625f,0.4375f,0.4375f,0.8125f,0.625f,0,true},
	{0.625f,0.5625f,0.4375f,0.6875f,0.8125f,0.625f,0,true},
	{0.3125f,0.8125f,0.3125f,0.75f,0.9375f,0.75f,1,true},
	{0.375f,0.9375f,0.375f,0.6875f,1.0f,0.6875f,1,true},
	{0.4375f,0.6562f,0.4375f,0.625f,0.8125f,0.625f,1,true}
};
static const ModelBox BOXES_laptop[] = {
	{0.0625f,0.0f,0.1875f,0.9375f,0.0625f,0.9375f,0,true},
	{0.125f,0.0625f,0.3125f,0.875f,0.07f,0.65f,1,true},
	{0.3125f,0.0625f,0.72f,0.5625f,0.07f,0.9f,0,true},
	{0.0625f,0.0625f,0.1875f,0.9375f,0.6875f,0.25f,0,true},
	{0.125f,0.125f,0.25f,0.875f,0.625f,0.27f,1,true}
};
static const ModelBox BOXES_couch_white[] = {
	{0.0f,0.0f,0.0f,1.0f,0.6f,1.0f,0,true},
	{0.75f,0.6f,0.0f,1.0f,1.2f,1.0f,0,true},
	{0.0f,0.6f,0.0f,0.75f,0.9f,0.15f,0,true},
	{0.0f,0.6f,0.85f,0.75f,0.9f,1.0f,0,true}
};
static const ModelBox BOXES_couch_green[] = {
	{0.0f,0.0f,0.0f,1.0f,0.6f,1.0f,0,true},
	{0.75f,0.6f,0.0f,1.0f,1.2f,1.0f,0,true},
	{0.0f,0.6f,0.0f,0.75f,0.9f,0.15f,0,true},
	{0.0f,0.6f,0.85f,0.75f,0.9f,1.0f,0,true}
};
static const ModelBox BOXES_couch_brown[] = {
	{0.0f,0.0f,0.0f,1.0f,0.6f,1.0f,0,true},
	{0.75f,0.6f,0.0f,1.0f,1.2f,1.0f,0,true},
	{0.0f,0.6f,0.0f,0.75f,0.9f,0.15f,0,true},
	{0.0f,0.6f,0.85f,0.75f,0.9f,1.0f,0,true}
};
static const ModelBox BOXES_couch_red[] = {
	{0.0f,0.0f,0.0f,1.0f,0.6f,1.0f,0,true},
	{0.75f,0.6f,0.0f,1.0f,1.2f,1.0f,0,true},
	{0.0f,0.6f,0.0f,0.75f,0.9f,0.15f,0,true},
	{0.0f,0.6f,0.85f,0.75f,0.9f,1.0f,0,true}
};
static const ModelBox BOXES_couch_black[] = {
	{0.0f,0.0f,0.0f,1.0f,0.6f,1.0f,0,true},
	{0.75f,0.6f,0.0f,1.0f,1.2f,1.0f,0,true},
	{0.0f,0.6f,0.0f,0.75f,0.9f,0.15f,0,true},
	{0.0f,0.6f,0.85f,0.75f,0.9f,1.0f,0,true}
};
static const ModelBox BOXES_bedside_cabinet[] = {
	{0.0625f,0.0f,0.0625f,0.9375f,0.75f,0.9375f,0,true},
	{0.0f,0.75f,0.0f,1.0f,0.8125f,1.0f,0,true}
};
static const ModelBox BOXES_rangehood[] = {
	{0.05f,0.0f,0.3f,0.95f,0.3f,1.0f,0,true},
	{0.35f,0.3f,0.7f,0.65f,1.0f,1.0f,0,true}
};
static const ModelBox BOXES_hedge_oak[] = {
	{0.125f,0.0f,0.125f,0.875f,0.9f,0.875f,0,false},
	{0.35f,0.9f,0.35f,0.65f,1.0f,0.65f,0,false}
};
static const ModelBox BOXES_hedge_spruce[] = {
	{0.125f,0.0f,0.125f,0.875f,0.9f,0.875f,0,false},
	{0.35f,0.9f,0.35f,0.65f,1.0f,0.65f,0,false}
};
static const ModelBox BOXES_hedge_birch[] = {
	{0.125f,0.0f,0.125f,0.875f,0.9f,0.875f,0,false},
	{0.35f,0.9f,0.35f,0.65f,1.0f,0.65f,0,false}
};
static const ModelBox BOXES_hedge_jungle[] = {
	{0.125f,0.0f,0.125f,0.875f,0.9f,0.875f,0,false},
	{0.35f,0.9f,0.35f,0.65f,1.0f,0.65f,0,false}
};

const ModelDef MODEL_DEFS[] = {
	{"aquarium", "Aquarium", "itemtv", 1, 1, 214, 460, 4, {"iron_block", "planks", "stone", "glass"}, {0, 5, 0, 0}, 17, BOXES_aquarium},
	{"canvas", "Canvas", "itemtv", 0, 0, 215, 461, 2, {"planks", "log"}, {0, 0}, 4, BOXES_canvas},
	{"chimney", "Chimney", "itemtv", 1, 0, 216, 462, 3, {"brick", "log", "stone"}, {0, 1, 0}, 20, BOXES_chimney},
	{"spiral_stairs", "Spiral Stairs", "itemtv", 0, 0, 217, 463, 2, {"iron_block", "planks"}, {0, 1}, 5, BOXES_spiral_stairs},
	{"bear_rug", "Bear Rug", "itemtv", 3, 0, 218, 464, 2, {"wool", "wool"}, {12, 15}, 11, BOXES_bear_rug},
	{"black_board", "Black Board", "itemtv", 0, 0, 224, 465, 3, {"planks", "wool", "wool"}, {0, 15, 0}, 7, BOXES_black_board},
	{"office_chair", "Office Chair", "itemchairwood", 2, 0, 225, 466, 2, {"iron_block", "wool"}, {0, 15}, 19, BOXES_office_chair},
	{"wheelie_bin", "Green Wheelie Bin", "itembin", 2, 0, 226, 467, 4, {"wool", "wool", "wool", "wool"}, {13, 5, 15, 0}, 20, BOXES_wheelie_bin},
	{"bottle", "Bottle", "itemdrink", 3, 1, 227, 468, 2, {"glass", "planks"}, {0, 0}, 30, BOXES_bottle},
	{"laptop", "Laptop", "itemcomputer", 2, 0, 228, 469, 2, {"iron_block", "wool"}, {0, 15}, 5, BOXES_laptop},
	{"couch_white", "White Couch", "itemcouch", 3, 0, 229, 492, 1, {"wool"}, {0}, 4, BOXES_couch_white},
	{"couch_green", "Green Couch", "itemcouch", 3, 0, 230, 493, 1, {"wool"}, {13}, 4, BOXES_couch_green},
	{"couch_brown", "Brown Couch", "itemcouch", 3, 0, 231, 494, 1, {"wool"}, {12}, 4, BOXES_couch_brown},
	{"couch_red", "Red Couch", "itemcouch", 3, 0, 232, 495, 1, {"wool"}, {14}, 4, BOXES_couch_red},
	{"couch_black", "Black Couch", "itemcouch", 3, 0, 233, 496, 1, {"wool"}, {15}, 4, BOXES_couch_black},
	{"bedside_cabinet", "Bedside Cabinet", "itembedsidecabinet", 0, 0, 234, 497, 1, {"planks"}, {2}, 2, BOXES_bedside_cabinet},
	{"rangehood", "Oven Rangehood", "itemrangehood", 2, 0, 235, 498, 1, {"iron_block"}, {0}, 2, BOXES_rangehood},
	{"hedge_oak", "Oak Hedge", "itemhedgebasic", 3, 0, 236, 499, 1, {"leaves"}, {4}, 2, BOXES_hedge_oak},
	{"hedge_spruce", "Spruce Hedge", "itemhedgespruce", 3, 0, 237, 500, 1, {"leaves"}, {5}, 2, BOXES_hedge_spruce},
	{"hedge_birch", "Birch Hedge", "itemhedgebirch", 3, 0, 238, 501, 1, {"leaves"}, {6}, 2, BOXES_hedge_birch},
	{"hedge_jungle", "Jungle Hedge", "itemhedgejungle", 3, 0, 239, 502, 1, {"leaves"}, {7}, 2, BOXES_hedge_jungle}
};
const int MODEL_COUNT = 21;
