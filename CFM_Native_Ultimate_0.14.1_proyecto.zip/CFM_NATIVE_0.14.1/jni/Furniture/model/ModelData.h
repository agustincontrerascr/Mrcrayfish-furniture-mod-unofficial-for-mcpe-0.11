#pragma once

struct ModelBox {
	float x1, y1, z1, x2, y2, z2;
	int tex;
	bool rotated;
};

#define MODEL_MAX_TEX 4

struct ModelDef {
	const char* key;
	const char* displayName;
	const char* icon;
	int material;      // 0 madera, 1 piedra, 2 hierro, 3 decoracion
	int glass;         // 1 = bloque translucido
	int blockId;
	int itemId;
	int numTex;
	const char* texName[MODEL_MAX_TEX];
	int texData[MODEL_MAX_TEX];
	int numBoxes;
	const ModelBox* boxes;
};

extern const ModelDef MODEL_DEFS[];
extern const int MODEL_COUNT;
