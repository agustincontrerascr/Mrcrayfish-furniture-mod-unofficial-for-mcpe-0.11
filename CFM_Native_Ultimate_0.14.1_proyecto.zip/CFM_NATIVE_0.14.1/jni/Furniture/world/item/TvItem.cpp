#include "TvItem.h"

int TvItem::_id = 491;   // 478 chocaba con ChoppingBoardItem

TvItem::TvItem(int id) : PlaceableItem("itemTV", id, TvBlock::_id) {
	setIcon("itemtv", 0);
}
