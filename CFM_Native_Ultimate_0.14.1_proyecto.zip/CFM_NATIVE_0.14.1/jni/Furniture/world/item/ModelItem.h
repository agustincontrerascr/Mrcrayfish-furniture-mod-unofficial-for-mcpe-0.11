#pragma once

#include <vector>
#include "PlaceableItem.h"
#include "../../model/ModelData.h"

class ModelItem : public PlaceableItem {
public:
	static std::vector<ModelItem*> all;
	static void createAll();
	static std::string getName(const ModelDef*);

	ModelItem(const ModelDef*);
};
