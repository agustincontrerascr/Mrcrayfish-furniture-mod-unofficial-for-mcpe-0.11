#include "ModelItem.h"

std::vector<ModelItem*> ModelItem::all;

std::string ModelItem::getName(const ModelDef* d) {
	return std::string("itemModel_") + d->key;
}

ModelItem::ModelItem(const ModelDef* d) : PlaceableItem(ModelItem::getName(d), d->itemId, d->blockId) {
	setIcon(d->icon, 0);
}

void ModelItem::createAll() {
	for(int i = 0; i < MODEL_COUNT; i++) {
		ModelItem* item = new ModelItem(&MODEL_DEFS[i]);
		Item::mItems[item->itemId] = item;
		all.push_back(item);
	}
}
