#pragma once

#include <vector>
#include "RotatableBlock.h"
#include "../../model/ModelData.h"

/* Bloque generico dirigido por una tabla de cajas (CFM CE, Device Mod y muebles portados del .js) */
class ModelBlock : public RotatableBlock {
public:
	static std::vector<ModelBlock*> all;
	static void createAll();
	static bool isModelBlock(Block*);

	ModelBlock(const ModelDef*, Material const&);

	virtual const TextureUVCoordinateSet& getTexture(signed char, int);
	virtual int getResource(Random&, int, int);

	const ModelDef* def;

private:
	std::vector<TextureUVCoordinateSet> texes;
};
