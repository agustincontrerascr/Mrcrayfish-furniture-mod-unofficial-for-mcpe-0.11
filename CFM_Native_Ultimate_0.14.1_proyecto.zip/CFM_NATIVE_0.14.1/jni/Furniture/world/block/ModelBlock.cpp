#include "ModelBlock.h"
#include "MCPE/world/material/Material.h"

std::vector<ModelBlock*> ModelBlock::all;

ModelBlock::ModelBlock(const ModelDef* d, Material const& material) : RotatableBlock(std::string("blockModel_") + d->key, d->blockId, material) {
	def = d;
	for(int i = 0; i < d->numTex; i++) {
		texes.push_back(getTextureUVCoordinateSet(d->texName[i], d->texData[i]));
	}
	tex = texes[0];

	setSolid(false);
	setDestroyTime(1.0F);
	if(d->glass) {
		setSoundType(Block::SOUND_GLASS);
		renderPass = mGlass->renderPass;
	} else if(d->material == 0) {
		setSoundType(Block::SOUND_WOOD);
	} else {
		setSoundType(Block::SOUND_STONE);
	}
}

const TextureUVCoordinateSet& ModelBlock::getTexture(signed char side, int data) {
	int i = side;
	if(i < 0 || i >= (int) texes.size()) i = 0;
	return texes[i];
}

int ModelBlock::getResource(Random& rand, int data, int idk) {
	return def->itemId;
}

bool ModelBlock::isModelBlock(Block* b) {
	for(unsigned i = 0; i < all.size(); i++) {
		if(all[i] == b) return true;
	}
	return false;
}

void ModelBlock::createAll() {
	for(int i = 0; i < MODEL_COUNT; i++) {
		const ModelDef* d = &MODEL_DEFS[i];
		MaterialType type = d->material == 0 ? MaterialType::WOOD : d->material == 1 ? MaterialType::STONE : d->material == 2 ? MaterialType::IRON : MaterialType::DECORATION;
		ModelBlock* block = new ModelBlock(d, Material::getMaterial(type));
		block->init();
		Block::mBlocks[block->id] = block;
		Item::mItems[block->id] = new BlockItem(block->getDescriptionId(), block->id - 256);
		all.push_back(block);
	}
}
