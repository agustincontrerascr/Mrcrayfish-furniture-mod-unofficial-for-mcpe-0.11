#include "ModelRenderer.h"

ModelRenderer::ModelRenderer(const ModelDef* d) : def(d) {
}

void ModelRenderer::render(const BlockPos& pos, FurnitureBlock& tile, BlockTessellator* tess) {
	tess->useForcedUV = true;
	int data = tess->region->getData({pos.x, pos.y, pos.z});

	for(int i = 0; i < def->numBoxes; i++) {
		const ModelBox& b = def->boxes[i];
		tess->forcedUV = tile.getTexture((signed char) b.tex, 0);
		if(b.rotated) {
			this->setRotatedBounds(tess, data, b.x1, b.y1, b.z1, b.x2, b.y2, b.z2);
		} else {
			tess->setRenderBounds(b.x1, b.y1, b.z1, b.x2, b.y2, b.z2);
		}
		tess->tessellateBlockInWorld(tile, pos);
	}

	tess->useForcedUV = false;
}
