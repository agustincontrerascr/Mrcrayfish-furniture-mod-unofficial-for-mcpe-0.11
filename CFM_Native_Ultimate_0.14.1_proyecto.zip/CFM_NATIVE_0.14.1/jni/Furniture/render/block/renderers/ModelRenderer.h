#pragma once

#include "../BlockRenderer.h"
#include "../../../model/ModelData.h"

class ModelRenderer : public BlockRenderer {
public:
	ModelRenderer(const ModelDef*);
	virtual void render(const BlockPos&, FurnitureBlock&, BlockTessellator*);
private:
	const ModelDef* def;
};
