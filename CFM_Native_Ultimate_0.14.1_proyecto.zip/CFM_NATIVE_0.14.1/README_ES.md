# CFM Native Ultimate 0.14.1 (todo en un mod nativo)

Mod nativo (C++ / BlockLauncher) con TODO el contenido, sin JavaScript:

* **Mod nativo original (sin tocar):** mesas, sillas, mesas de centro (madera/piedra), inodoro, armario,
  mueble de cocina, timbre, cubo, lámpara, tabla de cortar, tostadora, microondas, taburete,
  encimera, tarro de galletas, horno, plato, TV, cuchillo, cuadro y sentarse en sillas.
* **Portado del .js y de Couches_Only.js:** 5 sofás, mesita de noche, campana extractora, 4 setos.
* **Portado de CFM CE:** acuario, lienzo, chimenea, escalera de caracol, alfombra de oso, pizarra,
  silla de oficina, cubo verde, botella.
* **Portado del Device Mod:** laptop (solo el bloque; las apps no existen en nativo).

Los 21 bloques nuevos salen de UNA clase generica (`ModelBlock` / `ModelItem` / `ModelRenderer`)
alimentada por la tabla `jni/Furniture/model/ModelData.cpp` (cajas + texturas por mueble).

## IDs
* Bloques nuevos: 214-218 y 224-239.  Items nuevos: 460-469 y 492-502.
* Corregido del original: TV usaba el item 478 igual que la tabla de cortar (ahora 491);
  el tarro de galletas se creaba como `CounterBlock` (ahora `CookieJarBlock`); la TV no estaba en creativo.

## Como compilar el APK (necesario: no hay .so precompilado)
### Opcion A - sin instalar nada (GitHub Actions, sirve desde el movil)
1. Crea un repositorio en github.com y sube TODO el contenido de esta carpeta (incluida `.github`).
2. Pestaña **Actions** > **Build APK** > **Run workflow** (tambien corre solo al subir).
3. Al terminar, descarga el artefacto `CFM_Native_Ultimate_0.14.1_apk` (dentro viene el .apk firmado).

### Opcion B - en tu PC (Linux/macOS/WSL)
Necesitas **NDK r10e** (versiones nuevas NO sirven: este codigo usa gnustl y GCC 4.9) y un JDK:
`NDK=/ruta/android-ndk-r10e ./build_local.sh`

## Limitaciones (importante)
* **No esta compilado ni probado en el juego.** Verifique que los ~100 .cpp pasan un chequeo de sintaxis
  con g++, pero no pude generar el binario ARM ni ejecutarlo.
* Los headers de `jni/MCPE/` son de **MCPE 0.13.0b5**. En 0.14.1 pueden haber cambiado
  layouts/vtables/simbolos: si el juego se cierra al cargar, hay que actualizar esos headers.
* Los sofas y setos portados no se conectan con vecinos (el .js si lo hacia); cada uno es un modelo suelto.
* Los modelos de CE ignoran las rotaciones inclinadas de sus piezas (escalera de caracol, lienzo).
* La laptop no tiene interfaz/apps en nativo (eso era Java + GUI de Android).
