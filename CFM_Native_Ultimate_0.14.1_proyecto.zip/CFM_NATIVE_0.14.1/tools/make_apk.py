#!/usr/bin/env python3
"""Empaqueta y firma el APK del addon nativo.
Uso (despues de compilar con ndk-build):  python3 tools/make_apk.py
Requiere: python3 y un JDK (keytool + jarsigner) en el PATH.
"""
import struct, zipfile, os, subprocess, shutil, sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUTAPK=os.path.join(ROOT,'CFM_Native_Ultimate_0.14.1.apk')
LIBDIR=os.path.join(ROOT,'libs','armeabi-v7a')
NS='http://schemas.android.com/apk/res/android'
RES={'label':0x01010001,'name':0x01010003,'value':0x01010024,'hasCode':0x0101000c,
     'minSdkVersion':0x0101020c,'targetSdkVersion':0x01010270,'versionCode':0x0101021b,'versionName':0x0101021c}
# elementos: (tag, [(attr, tipo, valor)], hijos)
manifest=('manifest',[('package','s','com.mrcrayfish.furniturepe'),('versionCode','i',4),('versionName','s','4.0-0.14.1')],[
 ('uses-permission',[('name','s','net.zhuoweizhang.mcpelauncher.ADDON')],[]),
 ('uses-sdk',[('minSdkVersion','i',9),('targetSdkVersion','i',28)],[]),
 ('application',[('label','s','CFM Native Ultimate 0.14.1'),('hasCode','b',False)],[
   ('meta-data',[('name','s','net.zhuoweizhang.mcpelauncher.api.nativelibname'),('value','s','com.mrcrayfish.furniturepe')],[]),
   ('meta-data',[('name','s','net.zhuoweizhang.mcpelauncher.api.targetmcpeversion'),('value','s','0.14.1')],[]),
 ]),
])
# pool: primero atributos con resource id (ordenados por id), luego el resto
names=sorted(RES,key=lambda k:RES[k]); pool=list(names)
def S(s):
    if s not in pool: pool.append(s)
    return pool.index(s)
S('android'); S(NS)
def walk(e):
    S(e[0])
    for a,t,v in e[1]:
        if a not in RES: S(a)
        if t=='s': S(v)
    for c in e[2]: walk(c)
walk(manifest)
def u32(*v): return b''.join(struct.pack('<I',x&0xFFFFFFFF) for x in v)
def chunk_sp():
    offs=[];data=b''
    for s in pool:
        offs.append(len(data)); b=s.encode('utf-16-le')
        data+=struct.pack('<H',len(s))+b+b'\0\0'
    while len(data)%4: data+=b'\0'
    hdr=28; start=hdr+4*len(pool)
    body=u32(len(pool),0,0,start,0)+b''.join(u32(o) for o in offs)+data
    return struct.pack('<HHI',1,28,8+len(body)+0)[:0]+struct.pack('<HHI',1,28,28+4*len(pool)+len(data))+body
def ch(t,hs,body): return struct.pack('<HHI',t,hs,hs+len(body))+body
body=b''
rm=b''.join(u32(RES[n]) for n in names)
body+=struct.pack('<HHI',0x0180,8,8+len(rm))+rm
nsb=u32(1,0xFFFFFFFF,S('android'),S(NS))  # lineNo, comment, prefix, uri
body+=struct.pack('<HHI',0x0100,16,16+8)+nsb
def emit(e):
    out=b''
    attrs=[]
    for a,t,v in e[1]:
        ns=S(NS) if a in RES else 0xFFFFFFFF
        if t=='s': attrs.append((RES.get(a,0xFFFFFFFF),ns,S(a),S(v),0x03000008,S(v)))
        elif t=='i': attrs.append((RES.get(a,0xFFFFFFFF),ns,S(a),0xFFFFFFFF,0x10000008,v))
        else: attrs.append((RES.get(a,0xFFFFFFFF),ns,S(a),0xFFFFFFFF,0x12000008,0xFFFFFFFF if v else 0))
    attrs.sort(key=lambda x:(x[0]==0xFFFFFFFF and 0 or 1, x[0]) if False else (x[0]!=0xFFFFFFFF, x[0]))
    ab=b''
    for rid,ns,nm,raw,tv,data in attrs:
        size,res0,dtype=0x0008,0,(tv>>24)
        ab+=u32(ns,nm,raw)+struct.pack('<HBBI',8,0,dtype,data&0xFFFFFFFF)
    sb=u32(1,0xFFFFFFFF,0xFFFFFFFF,S(e[0]),0x00140014,len(attrs),0,0)  # ns,name,attrStart|attrSize,count,id,class,style
    # attrStart(0x14) y attrSize(0x14) son dos uint16
    sb=u32(1,0xFFFFFFFF,0xFFFFFFFF,S(e[0]))+struct.pack('<HHHHHH',0x14,0x14,len(attrs),0,0,0)+ab
    out+=struct.pack('<HHI',0x0102,16,16+len(sb)-8)+sb  # ver ajuste abajo
    for c in e[2]: out+=emit(c)
    eb=u32(1,0xFFFFFFFF,0xFFFFFFFF,S(e[0]))
    out+=struct.pack('<HHI',0x0103,16,16+8)+eb
    return out
body+=emit(manifest)
body+=struct.pack('<HHI',0x0101,16,16+8)+nsb
sp=chunk_sp()
total=8+len(sp)+len(body)
axml=struct.pack('<HHI',0x0003,8,total)+sp+body

axml_path=os.path.join(ROOT,'AndroidManifest.bin')
open(axml_path,'wb').write(axml)

libs=[f for f in os.listdir(LIBDIR) if f.endswith('.so')] if os.path.isdir(LIBDIR) else []
if not any(f.startswith('libcom.mrcrayfish.furniturepe') for f in libs):
    sys.exit('ERROR: no se encontro libs/armeabi-v7a/libcom.mrcrayfish.furniturepe.so. Ejecuta primero ndk-build.')
unsigned=os.path.join(ROOT,'unsigned.apk')
z=zipfile.ZipFile(unsigned,'w',zipfile.ZIP_DEFLATED)
z.write(axml_path,'AndroidManifest.xml')
for f in libs: z.write(os.path.join(LIBDIR,f),'lib/armeabi-v7a/'+f)
A=os.path.join(ROOT,'assets')
for r,_,fs in os.walk(A):
    for f in fs:
        full=os.path.join(r,f); z.write(full,'assets/'+os.path.relpath(full,A))
z.close()
ks=os.path.join(ROOT,'debug.jks')
if not os.path.exists(ks):
    subprocess.check_call(['keytool','-genkeypair','-keystore',ks,'-storepass','cfm12345','-keypass','cfm12345','-alias','cfm',
        '-keyalg','RSA','-keysize','2048','-validity','10000','-dname','CN=CFM Furniture, O=CFM'])
subprocess.check_call(['jarsigner','-keystore',ks,'-storepass','cfm12345','-keypass','cfm12345','-sigalg','SHA256withRSA',
    '-digestalg','SHA-256','-signedjar',OUTAPK,unsigned,'cfm'])
os.remove(unsigned); os.remove(axml_path)
print('APK listo:',OUTAPK)
