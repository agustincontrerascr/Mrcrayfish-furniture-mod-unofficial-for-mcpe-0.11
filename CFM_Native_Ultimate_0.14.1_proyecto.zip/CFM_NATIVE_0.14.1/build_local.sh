#!/bin/sh
# Compilacion local (Linux/macOS/WSL). Necesita NDK r10e: https://developer.android.com/ndk/downloads/older_releases
# Uso: NDK=/ruta/android-ndk-r10e ./build_local.sh
set -e
"${NDK:?define NDK=/ruta/android-ndk-r10e}"/ndk-build NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=jni/Android.mk NDK_APPLICATION_MK=jni/Application.mk
python3 tools/make_apk.py
