# MrCrayfish's Furniture Mod PE - edicion del script .js (20 muebles)

Este addon contiene exactamente los muebles activos del script MrCrayfishFurnitureModPE_a47146.js:

| Mueble | Bloque | Item |
|---|---|---|
| Mesa de madera / piedra | 200 / 201 | 460 / 461 |
| Silla de madera / piedra | 202 / 203 | 462 / 463 |
| Gabinete | 204 | 464 |
| Lampara | 207 | 467 |
| Mesa de centro madera / piedra | 208 / 209 | 468 / 469 |
| Sofas blanco, verde, cafe, rojo, negro | 211-215 | 471-475 |
| Mesa de noche | 216 | 476 |
| Horno | 217 | 477 |
| Campana | 218 | 478 |
| Setos roble, abeto, abedul, jungla | 219-222 | 479-482 |

Se ELIMINARON: inodoro, timbre y bote de basura (no estan en el script).
Se REEMPLAZO la lampara por la del script. Mesas, sillas y gabinete ya eran iguales a las del script.
Aparecen todos en el inventario creativo.

## Verificacion
La logica de formas (sofas, mesas de centro, lampara, horno, campana, setos) esta en
jni/Furniture/render/tile/*Logic.h y se comparo contra el .js: 0 diferencias.

## Compilar
Con GitHub Actions: sube este zip y .github/workflows/build.yml (ver build.yml aparte).
O con NDK r10e: ndk-build y luego empaquetar (build.xml). El manifest apunta a MCPE 0.11.0.
