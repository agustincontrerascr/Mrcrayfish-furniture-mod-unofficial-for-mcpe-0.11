#pragma once

// Piezas de lampara, horno, campana y setos (port directo de renderLamp, renderOven,
// renderOvenTop y renderHedge del script .js). Logica pura para poder probarla aparte.

struct TBox {
	float x1, y1, z1, x2, y2, z2;
	int tex;   // indice de textura del tile
	bool rot;  // true = se rota segun la orientacion del bloque
};

namespace ExtraLogic {

// Lampara: textura 0 = base (lana blanca), 1 = pantalla (cuarzo)
inline int lamp(TBox* o) {
	int n = 0;
	o[n++] = TBox{0.3f, 0.85f, 0.3f, 0.7f, 0.90f, 0.7f, 1, false};
	o[n++] = TBox{0.2f, 0.8f, 0.2f, 0.8f, 0.85f, 0.8f, 1, false};
	o[n++] = TBox{0.15f, 0.7f, 0.15f, 0.85f, 0.80f, 0.85f, 1, false};
	o[n++] = TBox{0.1f, 0.5f, 0.1f, 0.9f, 0.7f, 0.9f, 1, false};
	o[n++] = TBox{0.45f, 0.0f, 0.45f, 0.55f, 0.6f, 0.55f, 0, false};
	o[n++] = TBox{0.25f, 0.0f, 0.25f, 0.75f, 0.3125f, 0.75f, 0, false};
	return n;
}

// Horno: textura 0 = cuarzo, 1 = obsidiana, 2 = piedra
inline int oven(TBox* o) {
	int n = 0;
	o[n++] = TBox{0.0625f, 0.0f, 0.0625f, 0.9375f, 1.0f, 0.9375f, 0, false};
	o[n++] = TBox{0.1875f, 0.5f, 0.1875f, 0.4325f, 1.0625f, 0.4375f, 1, false};
	o[n++] = TBox{0.1875f, 0.5f, 0.5625f, 0.4325f, 1.0625f, 0.8125f, 1, false};
	o[n++] = TBox{0.5625f, 0.5f, 0.1875f, 0.8125f, 1.0625f, 0.4375f, 1, false};
	o[n++] = TBox{0.5625f, 0.5f, 0.5625f, 0.8125f, 1.0625f, 0.8125f, 1, false};
	o[n++] = TBox{0.875f, 0.0f, 0.0624f, 1.0f, 1.1875f, 0.9376f, 0, true};
	o[n++] = TBox{0.0f, 0.2f, 0.2f, 0.0625f, 0.8125f, 0.8f, 2, true};
	return n;
}

// Campana: textura 0 = losa de piedra, 1 = piedra, 2 = glowstone, 3 = obsidiana
inline int rangehood(TBox* o) {
	int n = 0;
	o[n++] = TBox{0.0f, 0.025f, 0.0f, 1.0f, 0.2f, 1.0f, 0, false};
	o[n++] = TBox{0.0f, 0.2f, 0.0f, 1.0f, 0.25f, 1.0f, 1, false};
	o[n++] = TBox{0.5f, 0.2f, 0.2f, 1.0f, 1.0f, 0.8f, 2, true};
	o[n++] = TBox{0.1f, 0.0f, 0.1f, 0.9f, 0.05f, 0.9f, 3, false};
	return n;
}

// Seto: textura 0 = hojas. connX1 = hay seto (o puerta 107) en x+1, connXm1 en x-1, etc.
inline int hedge(bool connX1, bool connXm1, bool connZ1, bool connZm1, TBox* o) {
	int n = 0;
	o[n++] = TBox{0.1875f, 0.0f, 0.1875f, 0.8125f, 1.0f, 0.8125f, 0, false};
	if(connX1)  o[n++] = TBox{0.8125f, 0.0f, 0.1875f, 1.0f, 1.0f, 0.8125f, 0, false};
	if(connXm1) o[n++] = TBox{0.0f, 0.0f, 0.1875f, 0.1875f, 1.0f, 0.8125f, 0, false};
	if(connZ1)  o[n++] = TBox{0.1875f, 0.0f, 0.8125f, 0.8125f, 1.0f, 1.0f, 0, false};
	if(connZm1) o[n++] = TBox{0.1875f, 0.0f, 0.0f, 0.8125f, 1.0f, 0.1875f, 0, false};
	return n;
}

}
