#pragma once

#include "../BlockRenderer.h"

class ExtraRenderer : public BlockRenderer {
public:
	enum Kind { OVEN = 0, RANGEHOOD = 1, HEDGE = 2 };

	ExtraRenderer(int);
	virtual void render(const TilePos&, FurnitureTile*, TileTessellator*);

private:
	int kind;
};
