#include "LampRenderer.h"

#include "../ExtraLogic.h"

void LampRenderer::render(const TilePos& pos, FurnitureTile* tile, TileTessellator* tess) {
	TBox boxes[8];
	int count = ExtraLogic::lamp(boxes);

	tess->useForcedUV = true;
	for(int i = 0; i < count; i++) {
		tess->forcedUV = tile->getTexture(boxes[i].tex, 0);
		tess->setRenderBounds(boxes[i].x1, boxes[i].y1, boxes[i].z1, boxes[i].x2, boxes[i].y2, boxes[i].z2);
		tess->tessellateBlockInWorld(tile, pos);
	}
	tess->useForcedUV = false;
}
