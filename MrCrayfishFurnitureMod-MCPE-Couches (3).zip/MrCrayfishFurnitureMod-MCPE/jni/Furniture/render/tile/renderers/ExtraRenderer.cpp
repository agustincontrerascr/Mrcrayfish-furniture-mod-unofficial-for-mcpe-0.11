#include "ExtraRenderer.h"

#include "../ExtraLogic.h"
#include "../../../world/tile/ExtraTile.h"

ExtraRenderer::ExtraRenderer(int k) : kind(k) {
}

// En el script los setos tambien se unen al bloque 107 (puerta de valla).
static bool joinsHedge(int id) {
	return ExtraTile::isHedgeId(id) || id == 107;
}

void ExtraRenderer::render(const TilePos& pos, FurnitureTile* tile, TileTessellator* tess) {
	int x = pos.x, y = pos.y, z = pos.z;
	int data = tess->region->getData(x, y, z);

	TBox boxes[8];
	int count = 0;
	if(kind == OVEN) {
		count = ExtraLogic::oven(boxes);
	} else if(kind == RANGEHOOD) {
		count = ExtraLogic::rangehood(boxes);
	} else {
		count = ExtraLogic::hedge(
			joinsHedge(tess->region->getTile(x + 1, y, z).id),
			joinsHedge(tess->region->getTile(x - 1, y, z).id),
			joinsHedge(tess->region->getTile(x, y, z + 1).id),
			joinsHedge(tess->region->getTile(x, y, z - 1).id),
			boxes);
	}

	tess->useForcedUV = true;
	for(int i = 0; i < count; i++) {
		tess->forcedUV = tile->getTexture(boxes[i].tex, 0);
		if(boxes[i].rot) {
			this->setRotatedBounds(tess, data, boxes[i].x1, boxes[i].y1, boxes[i].z1, boxes[i].x2, boxes[i].y2, boxes[i].z2);
		} else {
			tess->setRenderBounds(boxes[i].x1, boxes[i].y1, boxes[i].z1, boxes[i].x2, boxes[i].y2, boxes[i].z2);
		}
		tess->tessellateBlockInWorld(tile, pos);
	}
	tess->useForcedUV = false;
}
