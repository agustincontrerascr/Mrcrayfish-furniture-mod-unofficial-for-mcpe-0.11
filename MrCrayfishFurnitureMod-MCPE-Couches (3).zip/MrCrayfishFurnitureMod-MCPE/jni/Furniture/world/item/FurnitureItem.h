#pragma once

#include "MCPE/world/item/Item.h"

class FurnitureItem : public Item {
public:
	static FurnitureItem* itemTableWood;
	static FurnitureItem* itemTableStone;
	static FurnitureItem* itemChairWood;
	static FurnitureItem* itemChairStone;
	static FurnitureItem* itemCabinet;
	static FurnitureItem* itemLamp;
	static FurnitureItem* itemBedsideCabinet;
	static FurnitureItem* itemOven;
	static FurnitureItem* itemRangehood;
	static FurnitureItem* itemOakHedge;
	static FurnitureItem* itemSpruceHedge;
	static FurnitureItem* itemBirchHedge;
	static FurnitureItem* itemJungleHedge;
	static FurnitureItem* itemCoffeeTableWood;
	static FurnitureItem* itemCoffeeTableStone;
	static FurnitureItem* itemWhiteCouch;
	static FurnitureItem* itemGreenCouch;
	static FurnitureItem* itemBrownCouch;
	static FurnitureItem* itemRedCouch;
	static FurnitureItem* itemBlackCouch;

	FurnitureItem(int);
};