#pragma once

#include "PlaceableItem.h"
#include "../tile/CabinetTile.h"

class CabinetItem : public PlaceableItem {
public:
    static int _id;
    static int _bedsideId;

    CabinetItem(int, std::string, int);
};
