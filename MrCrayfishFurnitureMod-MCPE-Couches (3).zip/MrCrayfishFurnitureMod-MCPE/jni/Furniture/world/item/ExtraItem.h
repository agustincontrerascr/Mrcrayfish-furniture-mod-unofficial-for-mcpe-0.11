#pragma once

#include "PlaceableItem.h"

class ExtraItem : public PlaceableItem {
public:
	static int _ovenId;
	static int _rangehoodId;
	static int _oakHedgeId;
	static int _spruceHedgeId;
	static int _birchHedgeId;
	static int _jungleHedgeId;

	ExtraItem(int, std::string, int);
};
