#include "ExtraItem.h"

int ExtraItem::_ovenId = 477;
int ExtraItem::_rangehoodId = 478;
int ExtraItem::_oakHedgeId = 479;
int ExtraItem::_spruceHedgeId = 480;
int ExtraItem::_birchHedgeId = 481;
int ExtraItem::_jungleHedgeId = 482;

ExtraItem::ExtraItem(int id, std::string name, int tileId) : PlaceableItem(id, tileId) {
	setNameID(name);
	setIcon(name, 0);
}
