#include "FurnitureItem.h"

FurnitureItem* FurnitureItem::itemTableWood = NULL;
FurnitureItem* FurnitureItem::itemTableStone = NULL;
FurnitureItem* FurnitureItem::itemChairWood = NULL;
FurnitureItem* FurnitureItem::itemChairStone = NULL;
FurnitureItem* FurnitureItem::itemCabinet = NULL;
FurnitureItem* FurnitureItem::itemLamp = NULL;
FurnitureItem* FurnitureItem::itemBedsideCabinet = NULL;
FurnitureItem* FurnitureItem::itemOven = NULL;
FurnitureItem* FurnitureItem::itemRangehood = NULL;
FurnitureItem* FurnitureItem::itemOakHedge = NULL;
FurnitureItem* FurnitureItem::itemSpruceHedge = NULL;
FurnitureItem* FurnitureItem::itemBirchHedge = NULL;
FurnitureItem* FurnitureItem::itemJungleHedge = NULL;
FurnitureItem* FurnitureItem::itemCoffeeTableWood = NULL;
FurnitureItem* FurnitureItem::itemCoffeeTableStone = NULL;
FurnitureItem* FurnitureItem::itemWhiteCouch = NULL;
FurnitureItem* FurnitureItem::itemGreenCouch = NULL;
FurnitureItem* FurnitureItem::itemBrownCouch = NULL;
FurnitureItem* FurnitureItem::itemRedCouch = NULL;
FurnitureItem* FurnitureItem::itemBlackCouch = NULL;

FurnitureItem::FurnitureItem(int id) : Item(id - 256) {
	creativeCategory = 4;
}
