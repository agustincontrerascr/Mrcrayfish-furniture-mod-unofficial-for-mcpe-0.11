#include "CabinetItem.h"

int CabinetItem::_id = 464;
int CabinetItem::_bedsideId = 476;

CabinetItem::CabinetItem(int id, std::string name, int tileId) : PlaceableItem(id, tileId) {
	setNameID(name);
	setIcon(name, 0);
}
