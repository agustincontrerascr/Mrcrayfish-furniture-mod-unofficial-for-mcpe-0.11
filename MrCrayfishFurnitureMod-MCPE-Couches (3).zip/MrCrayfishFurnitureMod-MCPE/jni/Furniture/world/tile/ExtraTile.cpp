#include "ExtraTile.h"

#include "MCPE/world/material/Material.h"

int ExtraTile::_ovenId = 217;
int ExtraTile::_rangehoodId = 218;
int ExtraTile::_oakHedgeId = 219;
int ExtraTile::_spruceHedgeId = 220;
int ExtraTile::_birchHedgeId = 221;
int ExtraTile::_jungleHedgeId = 222;

bool ExtraTile::isHedgeId(int id) {
	return id == _oakHedgeId || id == _spruceHedgeId || id == _birchHedgeId || id == _jungleHedgeId;
}

ExtraTile::ExtraTile(int id, std::string name, Material const* material, int item, const ExtraTex* texs, int count) : RotatableTile(id, material) {
	Tile::solid[id] = false;
	Tile::lightBlock[id] = 0;

	setNameId(name);
	setDestroyTime(0.8F);
	droppedItem = item;
	texCount = count > 4 ? 4 : count;
	for(int i = 0; i < texCount; i++) {
		uvs[i] = getTextureUVCoordinateSet(texs[i].name, texs[i].index);
	}
	tex = uvs[0];
}

const TextureUVCoordinateSet& ExtraTile::getTexture(signed char side, int data) {
	if(side < 0 || side >= texCount) return uvs[0];
	return uvs[side];
}

bool ExtraTile::use(Player* player, int x, int y, int z) {
	return false;
}

int ExtraTile::getResource(int data, Random* rand) {
	return droppedItem;
}
