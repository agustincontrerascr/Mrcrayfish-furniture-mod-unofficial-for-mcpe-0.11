#pragma once

#include "RotatableTile.h"
#include "../item/CabinetItem.h"

class CabinetTile: public RotatableTile {
public:
	static int _id;
	static int _bedsideId;
	
	CabinetTile(int, Material const*, std::string, int);

	virtual const TextureUVCoordinateSet& getTexture(signed char, int);
	virtual int getResource(int, Random*);
	virtual bool use(Player*, int, int, int);
	virtual void addAABBs(TileSource*, int, int, int, AABB const*, std::vector<AABB, std::allocator<AABB>>&);
	
private:
	int droppedItem;
	TextureUVCoordinateSet secondary_tex;
	TextureUVCoordinateSet terciary_tex;
};
