#include "FurnitureTile.h"

FurnitureTile* FurnitureTile::tileTableWood = NULL;
FurnitureTile* FurnitureTile::tileTableStone = NULL;
FurnitureTile* FurnitureTile::tileChairWood = NULL;
FurnitureTile* FurnitureTile::tileChairStone = NULL;
FurnitureTile* FurnitureTile::tileCabinet = NULL;
FurnitureTile* FurnitureTile::tileLamp = NULL;
FurnitureTile* FurnitureTile::tileBedsideCabinet = NULL;
FurnitureTile* FurnitureTile::tileOven = NULL;
FurnitureTile* FurnitureTile::tileRangehood = NULL;
FurnitureTile* FurnitureTile::tileOakHedge = NULL;
FurnitureTile* FurnitureTile::tileSpruceHedge = NULL;
FurnitureTile* FurnitureTile::tileBirchHedge = NULL;
FurnitureTile* FurnitureTile::tileJungleHedge = NULL;
FurnitureTile* FurnitureTile::tileCoffeeTableWood = NULL;
FurnitureTile* FurnitureTile::tileCoffeeTableStone = NULL;
FurnitureTile* FurnitureTile::tileWhiteCouch = NULL;
FurnitureTile* FurnitureTile::tileGreenCouch = NULL;
FurnitureTile* FurnitureTile::tileBrownCouch = NULL;
FurnitureTile* FurnitureTile::tileRedCouch = NULL;
FurnitureTile* FurnitureTile::tileBlackCouch = NULL;

FurnitureTile::FurnitureTile(int id, Material const* material) : Tile(id, material) {
	init();
	category = 1;

	new TileItem(id - 256);
}
