#pragma once

#include "RotatableTile.h"

struct ExtraTex {
	const char* name;
	int index;
};

// Bloque con hasta 4 texturas (horno, campana, setos).
class ExtraTile : public RotatableTile {
public:
	static int _ovenId;
	static int _rangehoodId;
	static int _oakHedgeId;
	static int _spruceHedgeId;
	static int _birchHedgeId;
	static int _jungleHedgeId;

	static bool isHedgeId(int id);

	ExtraTile(int, std::string, Material const*, int, const ExtraTex*, int);

	virtual const TextureUVCoordinateSet& getTexture(signed char, int);
	virtual int getResource(int, Random*);
	virtual bool use(Player*, int, int, int);

private:
	int droppedItem;
	int texCount;
	TextureUVCoordinateSet uvs[4];
};
