#include <jni.h>
#include <dlfcn.h>
#include <android/log.h>
#include <stdlib.h>
#include <substrate.h>
#include <vector>

#include "MCPE/world/level/tile/Tile.h"
#include "MCPE/world/level/tile/LiquidTileDynamic.h"
#include "MCPE/world/material/Material.h"
#include "MCPE/world/item/Item.h"
#include "MCPE/client/renderer/tile/TileTessellator.h"
#include "MCPE/locale/I18n.h"
#include "MCPE/world/entity/Motive.h"

#include "Furniture/render/tile/RenderDispatcher.h"
#include "Furniture/render/tile/renderers/ChairRenderer.h"
#include "Furniture/render/tile/renderers/TableRenderer.h"
#include "Furniture/render/tile/renderers/CabinetRenderer.h"
#include "Furniture/render/tile/renderers/LampRenderer.h"
#include "Furniture/render/tile/renderers/CouchRenderer.h"
#include "Furniture/render/tile/renderers/ExtraRenderer.h"
#include "Furniture/render/tile/renderers/CoffeeTableRenderer.h"
#include "Furniture/world/tile/FurnitureTile.h"
#include "Furniture/world/tile/TableTile.h"
#include "Furniture/world/tile/ChairTile.h"
#include "Furniture/world/tile/CabinetTile.h"
#include "Furniture/world/tile/LampTile.h"
#include "Furniture/world/tile/CouchTile.h"
#include "Furniture/world/tile/ExtraTile.h"
#include "Furniture/world/tile/CoffeeTableTile.h"
#include "Furniture/world/item/FurnitureItem.h"
#include "Furniture/world/item/TableItem.h"
#include "Furniture/world/item/ChairItem.h"
#include "Furniture/world/item/CabinetItem.h"
#include "Furniture/world/item/LampItem.h"
#include "Furniture/world/item/CouchItem.h"
#include "Furniture/world/item/ExtraItem.h"
#include "Furniture/world/item/CoffeeTableItem.h"
#include "Furniture/world/item/material/ItemMaterial.h"
#include "Furniture/world/tile/attributes/FurnitureTileAttributes.h"


void initMod() {
	Motive::initCustomMotives();
}

static void (*_TileTessellator$tessellateInWorld)(TileTessellator*, Tile*, const TilePos&, bool);
static void TileTessellator$tessellateInWorld(TileTessellator* self, Tile* tile, const TilePos& pos, bool b) {
	if(!RenderDispatcher::dispatch(tile->id, pos, tile, self))
		_TileTessellator$tessellateInWorld(self, tile, pos, b);
}

void initRenderers() {
	RenderDispatcher::registerRenderer(TableTile::_woodId, new TableRenderer());
	RenderDispatcher::registerRenderer(TableTile::_stoneId, new TableRenderer());
	RenderDispatcher::registerRenderer(CoffeeTableTile::_woodId, new CoffeeTableRenderer());
	RenderDispatcher::registerRenderer(CoffeeTableTile::_stoneId, new CoffeeTableRenderer());
	RenderDispatcher::registerRenderer(ChairTile::_woodId, new ChairRenderer());
	RenderDispatcher::registerRenderer(ChairTile::_stoneId, new ChairRenderer());
	RenderDispatcher::registerRenderer(CabinetTile::_id, new CabinetRenderer());
	RenderDispatcher::registerRenderer(CabinetTile::_bedsideId, new CabinetRenderer());
	RenderDispatcher::registerRenderer(ExtraTile::_ovenId, new ExtraRenderer(ExtraRenderer::OVEN));
	RenderDispatcher::registerRenderer(ExtraTile::_rangehoodId, new ExtraRenderer(ExtraRenderer::RANGEHOOD));
	RenderDispatcher::registerRenderer(ExtraTile::_oakHedgeId, new ExtraRenderer(ExtraRenderer::HEDGE));
	RenderDispatcher::registerRenderer(ExtraTile::_spruceHedgeId, new ExtraRenderer(ExtraRenderer::HEDGE));
	RenderDispatcher::registerRenderer(ExtraTile::_birchHedgeId, new ExtraRenderer(ExtraRenderer::HEDGE));
	RenderDispatcher::registerRenderer(ExtraTile::_jungleHedgeId, new ExtraRenderer(ExtraRenderer::HEDGE));
	RenderDispatcher::registerRenderer(LampTile::_id, new LampRenderer());
	RenderDispatcher::registerRenderer(CouchTile::_whiteId, new CouchRenderer());
	RenderDispatcher::registerRenderer(CouchTile::_greenId, new CouchRenderer());
	RenderDispatcher::registerRenderer(CouchTile::_brownId, new CouchRenderer());
	RenderDispatcher::registerRenderer(CouchTile::_redId, new CouchRenderer());
	RenderDispatcher::registerRenderer(CouchTile::_blackId, new CouchRenderer());
}

static void (*_Tile$initTiles)();
static void Tile$initTiles() {
	_Tile$initTiles();

	FurnitureTileAttributes woodAttributes(&Material::wood, "planks", "log", Tile::SOUND_WOOD, 1.0F);
	FurnitureTileAttributes stoneAttributes(&Material::stone, "stone", "cobblestone", Tile::SOUND_STONE, 1.5F);

	FurnitureTile::tileTableWood = new TableTile(TableTile::_woodId, "woodTableTile", woodAttributes, TableItem::_woodId);
	FurnitureTile::tileTableStone = new TableTile(TableTile::_stoneId, "stoneTableTile", stoneAttributes, TableItem::_stoneId);
	FurnitureTile::tileCoffeeTableWood = new CoffeeTableTile(CoffeeTableTile::_woodId, "woodCoffeeTableTile", woodAttributes, CoffeeTableItem::_woodId, false);
	FurnitureTile::tileCoffeeTableStone = new CoffeeTableTile(CoffeeTableTile::_stoneId, "stoneCoffeeTableTile", stoneAttributes, CoffeeTableItem::_stoneId, true);
	FurnitureTile::tileChairWood = new ChairTile(ChairTile::_woodId, "woodChairTile", woodAttributes, ChairItem::_woodId);
	FurnitureTile::tileChairStone = new ChairTile(ChairTile::_stoneId, "stoneChairTile", stoneAttributes, ChairItem::_stoneId);
	FurnitureTile::tileCabinet = new CabinetTile(CabinetTile::_id, &Material::wood, "tileCabinet", CabinetItem::_id);
	FurnitureTile::tileBedsideCabinet = new CabinetTile(CabinetTile::_bedsideId, &Material::wood, "tileBedsideCabinet", CabinetItem::_bedsideId);
	FurnitureTile::tileLamp = new LampTile(LampTile::_id, &Material::stone);
	FurnitureTile::tileWhiteCouch = new CouchTile(CouchTile::_whiteId, "whiteCouchTile", 0, CouchItem::_whiteId);
	FurnitureTile::tileGreenCouch = new CouchTile(CouchTile::_greenId, "greenCouchTile", 13, CouchItem::_greenId);
	FurnitureTile::tileBrownCouch = new CouchTile(CouchTile::_brownId, "brownCouchTile", 12, CouchItem::_brownId);
	FurnitureTile::tileRedCouch = new CouchTile(CouchTile::_redId, "redCouchTile", 14, CouchItem::_redId);
	FurnitureTile::tileBlackCouch = new CouchTile(CouchTile::_blackId, "blackCouchTile", 15, CouchItem::_blackId);

	static const ExtraTex ovenTex[] = {{"quartz_block", 1}, {"obsidian", 0}, {"stone", 0}};
	static const ExtraTex rangehoodTex[] = {{"stone_slab", 0}, {"stone", 0}, {"glowstone", 0}, {"obsidian", 0}};
	static const ExtraTex oakLeaves[] = {{"leaves", 4}};
	static const ExtraTex spruceLeaves[] = {{"leaves", 5}};
	static const ExtraTex birchLeaves[] = {{"leaves", 6}};
	static const ExtraTex jungleLeaves[] = {{"leaves", 7}};
	FurnitureTile::tileOven = new ExtraTile(ExtraTile::_ovenId, "tileOven", &Material::stone, ExtraItem::_ovenId, ovenTex, 3);
	FurnitureTile::tileRangehood = new ExtraTile(ExtraTile::_rangehoodId, "tileRangehood", &Material::stone, ExtraItem::_rangehoodId, rangehoodTex, 4);
	FurnitureTile::tileOakHedge = new ExtraTile(ExtraTile::_oakHedgeId, "tileOakHedge", &Material::wood, ExtraItem::_oakHedgeId, oakLeaves, 1);
	FurnitureTile::tileSpruceHedge = new ExtraTile(ExtraTile::_spruceHedgeId, "tileSpruceHedge", &Material::wood, ExtraItem::_spruceHedgeId, spruceLeaves, 1);
	FurnitureTile::tileBirchHedge = new ExtraTile(ExtraTile::_birchHedgeId, "tileBirchHedge", &Material::wood, ExtraItem::_birchHedgeId, birchLeaves, 1);
	FurnitureTile::tileJungleHedge = new ExtraTile(ExtraTile::_jungleHedgeId, "tileJungleHedge", &Material::wood, ExtraItem::_jungleHedgeId, jungleLeaves, 1);

	initRenderers();
}

static void (*_Item$initItems)();
static void Item$initItems() {
	FurnitureItem::itemTableWood = new TableItem(TableItem::_woodId, "woodTableItem", ItemMaterial::WOOD, TableTile::_woodId);
	FurnitureItem::itemTableStone = new TableItem(TableItem::_stoneId, "stoneTableItem", ItemMaterial::STONE, TableTile::_stoneId);
	FurnitureItem::itemCoffeeTableWood = new CoffeeTableItem(CoffeeTableItem::_woodId, "woodCoffeeTableItem", CoffeeTableTile::_woodId);
	FurnitureItem::itemCoffeeTableStone = new CoffeeTableItem(CoffeeTableItem::_stoneId, "stoneCoffeeTableItem", CoffeeTableTile::_stoneId);
	FurnitureItem::itemChairWood = new ChairItem(ChairItem::_woodId, "woodChairItem", ItemMaterial::WOOD, ChairTile::_woodId);
	FurnitureItem::itemChairStone = new ChairItem(ChairItem::_stoneId, "stoneChairItem", ItemMaterial::STONE, ChairTile::_stoneId);
	FurnitureItem::itemCabinet = new CabinetItem(CabinetItem::_id, "cabinetItem", CabinetTile::_id);
	FurnitureItem::itemBedsideCabinet = new CabinetItem(CabinetItem::_bedsideId, "bedsideCabinetItem", CabinetTile::_bedsideId);
	FurnitureItem::itemLamp = new LampItem(LampItem::_id);
	FurnitureItem::itemWhiteCouch = new CouchItem(CouchItem::_whiteId, "whiteCouchItem", CouchTile::_whiteId);
	FurnitureItem::itemGreenCouch = new CouchItem(CouchItem::_greenId, "greenCouchItem", CouchTile::_greenId);
	FurnitureItem::itemBrownCouch = new CouchItem(CouchItem::_brownId, "brownCouchItem", CouchTile::_brownId);
	FurnitureItem::itemRedCouch = new CouchItem(CouchItem::_redId, "redCouchItem", CouchTile::_redId);
	FurnitureItem::itemBlackCouch = new CouchItem(CouchItem::_blackId, "blackCouchItem", CouchTile::_blackId);
	FurnitureItem::itemOven = new ExtraItem(ExtraItem::_ovenId, "ovenItem", ExtraTile::_ovenId);
	FurnitureItem::itemRangehood = new ExtraItem(ExtraItem::_rangehoodId, "rangeHoodItem", ExtraTile::_rangehoodId);
	FurnitureItem::itemOakHedge = new ExtraItem(ExtraItem::_oakHedgeId, "oakHedgeItem", ExtraTile::_oakHedgeId);
	FurnitureItem::itemSpruceHedge = new ExtraItem(ExtraItem::_spruceHedgeId, "spruceHedgeItem", ExtraTile::_spruceHedgeId);
	FurnitureItem::itemBirchHedge = new ExtraItem(ExtraItem::_birchHedgeId, "birchHedgeItem", ExtraTile::_birchHedgeId);
	FurnitureItem::itemJungleHedge = new ExtraItem(ExtraItem::_jungleHedgeId, "jungleHedgeItem", ExtraTile::_jungleHedgeId);

	_Item$initItems();
}

static void (*_Item$initCreativeItems)();
static void Item$initCreativeItems() {
	_Item$initCreativeItems();

	Item::addCreativeItem(FurnitureItem::itemTableWood, 0);
	Item::addCreativeItem(FurnitureItem::itemTableStone, 0);
	Item::addCreativeItem(FurnitureItem::itemCoffeeTableWood, 0);
	Item::addCreativeItem(FurnitureItem::itemCoffeeTableStone, 0);
	Item::addCreativeItem(FurnitureItem::itemChairWood, 0);
	Item::addCreativeItem(FurnitureItem::itemChairStone, 0);
	Item::addCreativeItem(FurnitureItem::itemCabinet, 0);
	Item::addCreativeItem(FurnitureItem::itemBedsideCabinet, 0);
	Item::addCreativeItem(FurnitureItem::itemLamp, 0);
	Item::addCreativeItem(FurnitureItem::itemWhiteCouch, 0);
	Item::addCreativeItem(FurnitureItem::itemGreenCouch, 0);
	Item::addCreativeItem(FurnitureItem::itemBrownCouch, 0);
	Item::addCreativeItem(FurnitureItem::itemRedCouch, 0);
	Item::addCreativeItem(FurnitureItem::itemBlackCouch, 0);
	Item::addCreativeItem(FurnitureItem::itemOven, 0);
	Item::addCreativeItem(FurnitureItem::itemRangehood, 0);
	Item::addCreativeItem(FurnitureItem::itemOakHedge, 0);
	Item::addCreativeItem(FurnitureItem::itemSpruceHedge, 0);
	Item::addCreativeItem(FurnitureItem::itemBirchHedge, 0);
	Item::addCreativeItem(FurnitureItem::itemJungleHedge, 0);
}

static std::string (*_I18n$get)(std::string const&, std::vector<std::string, std::allocator<std::string>> const&);
static std::string I18n$get(std::string const& key, std::vector<std::string, std::allocator<std::string>> const& a) {
	if(key == "item.woodTableItem.name") return "Wooden Table";
	if(key == "item.stoneTableItem.name") return "Stone Table";
	if(key == "item.woodCoffeeTableItem.name") return "Wooden Coffee Table";
	if(key == "item.stoneCoffeeTableItem.name") return "Stone Coffee Table";
	if(key == "item.woodChairItem.name") return "Wooden Chair";
	if(key == "item.stoneChairItem.name") return "Stone Chair";
	if(key == "item.bathItem.name") return "Bath";
	if(key == "item.showerItem.name") return "Shower";
	if(key == "item.showerHeadItem.name") return "Shower Head";
	if(key == "item.cabinetItem.name") return "Cabinet";
	if(key == "item.bedsideCabinetItem.name") return "Bedside Cabinet";
	if(key == "item.tvItem.name") return "TV";
	if(key == "item.fridgeItem.name") return "Fridge";
	if(key == "item.ovenItem.name") return "Oven";
	if(key == "item.blenderItem.name") return "Blender";
	if(key == "item.lampItem.name") return "Lamp";
	if(key == "item.rangeHoodItem.name") return "Oven Rangehood";
	if(key == "item.oakHedgeItem.name") return "Oak Hedge";
	if(key == "item.spruceHedgeItem.name") return "Spruce Hedge";
	if(key == "item.birchHedgeItem.name") return "Birch Hedge";
	if(key == "item.jungleHedgeItem.name") return "Jungle Hedge";
	if(key == "item.whiteCouchItem.name") return "White Couch";
	if(key == "item.greenCouchItem.name") return "Green Couch";
	if(key == "item.brownCouchItem.name") return "Brown Couch";
	if(key == "item.redCouchItem.name") return "Red Couch";
	if(key == "item.blackCouchItem.name") return "Black Couch";
	
	return _I18n$get(key, a);
}

static bool (*_LiquidTileDynamic$_isWaterBlocking)(LiquidTileDynamic*, TileSource*, const TilePos&);
static bool LiquidTileDynamic$_isWaterBlocking(LiquidTileDynamic* self, TileSource* region, const TilePos& pos) {
	Tile* tile = region->getTilePtr(pos.x, pos.y, pos.z);
	if(tile == FurnitureTile::tileTableWood ||
     	tile == FurnitureTile::tileTableStone ||
		tile == FurnitureTile::tileCoffeeTableWood ||
		tile == FurnitureTile::tileCoffeeTableStone ||
		tile == FurnitureTile::tileChairWood ||
		tile == FurnitureTile::tileChairStone ||
		tile == FurnitureTile::tileCabinet ||
		tile == FurnitureTile::tileLamp ||
		tile == FurnitureTile::tileBedsideCabinet ||
		tile == FurnitureTile::tileOven ||
		tile == FurnitureTile::tileRangehood ||
		tile == FurnitureTile::tileOakHedge ||
		tile == FurnitureTile::tileSpruceHedge ||
		tile == FurnitureTile::tileBirchHedge ||
		tile == FurnitureTile::tileJungleHedge ||
		tile == FurnitureTile::tileWhiteCouch ||
		tile == FurnitureTile::tileGreenCouch ||
		tile == FurnitureTile::tileBrownCouch ||
		tile == FurnitureTile::tileRedCouch ||
		tile == FurnitureTile::tileBlackCouch)
			return true;
	
	return _LiquidTileDynamic$_isWaterBlocking(self, region, pos);
}

static std::vector<const Motive*> (*_Motive$getAllMotivesAsList)();
static std::vector<const Motive*> Motive$getAllMotivesAsList() {
	std::vector<const Motive*> retval = _Motive$getAllMotivesAsList();
	retval.push_back(Motive::Furniture);
	return retval;
}


JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void* reserved) {
	initMod();

	MSHookFunction((void*) &TileTessellator::tessellateInWorld, (void*) &TileTessellator$tessellateInWorld, (void**) &_TileTessellator$tessellateInWorld);
	MSHookFunction((void*) &Item::initItems, (void*) &Item$initItems, (void**) &_Item$initItems);
	MSHookFunction((void*) &Tile::initTiles, (void*) &Tile$initTiles, (void**) &_Tile$initTiles);
	MSHookFunction((void*) &Item::initCreativeItems, (void*) &Item$initCreativeItems, (void**) &_Item$initCreativeItems);
	MSHookFunction((void*) &I18n::get, (void*) &I18n$get, (void**) &_I18n$get);
	MSHookFunction((void*) &LiquidTileDynamic::_isWaterBlocking, (void*) &LiquidTileDynamic$_isWaterBlocking, (void**) &_LiquidTileDynamic$_isWaterBlocking);
	MSHookFunction((void*) &Motive::getAllMotivesAsList, (void*) &Motive$getAllMotivesAsList, (void**) &_Motive$getAllMotivesAsList);

	return JNI_VERSION_1_2;
}
