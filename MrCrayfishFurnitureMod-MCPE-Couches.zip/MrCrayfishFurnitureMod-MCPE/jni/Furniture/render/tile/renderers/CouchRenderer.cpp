#include "CouchRenderer.h"

#include "../CouchLogic.h"
#include "../../../world/tile/CouchTile.h"

namespace {
struct RegionAccess {
	TileSource* region;
	int tile(int x, int y, int z) { return region->getTile(x, y, z).id; }
	int data(int x, int y, int z) { return region->getData(x, y, z); }
	bool isCouchId(int id) { return CouchTile::isCouchId(id); }
};
}

void CouchRenderer::render(const TilePos& pos, FurnitureTile* tile, TileTessellator* tess) {
	int x = pos.x, y = pos.y, z = pos.z;
	int data = tess->region->getData(x, y, z);

	RegionAccess acc;
	acc.region = tess->region;

	CouchBox boxes[8];
	int count = CouchLogic::computeBoxes(acc, x, y, z, data, boxes);

	tess->useForcedUV = true;
	tess->forcedUV = tile->getTexture(0, 0);

	for(int i = 0; i < count; i++) {
		this->setRotatedBounds(tess, data, boxes[i].x1, boxes[i].y1, boxes[i].z1, boxes[i].x2, boxes[i].y2, boxes[i].z2);
		tess->tessellateBlockInWorld(tile, {x, y, z});
	}

	tess->useForcedUV = false;
}
