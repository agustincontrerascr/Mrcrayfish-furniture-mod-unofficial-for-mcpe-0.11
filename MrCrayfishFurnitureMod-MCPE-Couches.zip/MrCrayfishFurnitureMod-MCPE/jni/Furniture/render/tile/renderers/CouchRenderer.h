#pragma once

#include "../BlockRenderer.h"

class CouchRenderer : public BlockRenderer {
public:
	virtual void render(const TilePos&, FurnitureTile*, TileTessellator*);
};
