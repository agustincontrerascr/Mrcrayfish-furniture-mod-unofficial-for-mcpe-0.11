#pragma once

// Logica pura (sin dependencias de MCPE) de como se conectan los sofas.
// Es un port directo de renderCouch/isCouch/isAirBlock/getRotation/getMetadata
// del script MrCrayfishFurnitureModPE.js, para poder probarla aparte.

struct CouchBox {
	float x1, y1, z1, x2, y2, z2;
};

namespace CouchLogic {

enum Rot { UP = 0, DOWN = 1, LEFT = 2, RIGHT = 3 };

// Desplazamiento (dx, dz) del vecino segun la orientacion del sofa y la direccion pedida.
inline void offset(int meta, int rotation, int& dx, int& dz) {
	dx = 0; dz = 0;
	switch(rotation) {
	case UP:
		if(meta == 3) dx = 1;
		else if(meta == 1) dx = -1;
		else if(meta == 2) dz = -1;
		else if(meta == 0) dz = 1;
		break;
	case DOWN:
		if(meta == 3) dx = -1;
		else if(meta == 1) dx = 1;
		else if(meta == 2) dz = 1;
		else if(meta == 0) dz = -1;
		break;
	case LEFT:
		if(meta == 2) dx = -1;
		else if(meta == 0) dx = 1;
		else if(meta == 3) dz = -1;
		else if(meta == 1) dz = 1;
		break;
	case RIGHT:
		if(meta == 2) dx = 1;
		else if(meta == 0) dx = -1;
		else if(meta == 3) dz = 1;
		else if(meta == 1) dz = -1;
		break;
	}
}

inline int rotationFor(int meta, int neighborMeta) {
	switch(meta) {
	case 3:
		if(neighborMeta == 3) return DOWN;
		if(neighborMeta == 1) return UP;
		if(neighborMeta == 2) return RIGHT;
		if(neighborMeta == 0) return LEFT;
		break;
	case 1:
		if(neighborMeta == 3) return UP;
		if(neighborMeta == 1) return DOWN;
		if(neighborMeta == 2) return LEFT;
		if(neighborMeta == 0) return RIGHT;
		break;
	case 2:
		if(neighborMeta == 3) return LEFT;
		if(neighborMeta == 1) return RIGHT;
		if(neighborMeta == 2) return DOWN;
		if(neighborMeta == 0) return UP;
		break;
	case 0:
		if(neighborMeta == 3) return RIGHT;
		if(neighborMeta == 1) return LEFT;
		if(neighborMeta == 2) return UP;
		if(neighborMeta == 0) return DOWN;
		break;
	}
	return 0;
}

// A debe tener: int tile(int x, int y, int z); int data(int x, int y, int z); bool isCouchId(int id);
// Escribe las cajas (en espacio sin rotar) en out (minimo 5 huecos) y devuelve cuantas son.
template<class A>
int computeBoxes(A& acc, int x, int y, int z, int meta, CouchBox* out) {
	int n = 0;
	int dx, dz;

	offset(meta, DOWN, dx, dz);
	bool couchDown = acc.isCouchId(acc.tile(x + dx, y, z + dz));
	bool airLeft, airRight;
	offset(meta, LEFT, dx, dz);
	airLeft = acc.tile(x + dx, y, z + dz) == 0;
	offset(meta, RIGHT, dx, dz);
	airRight = acc.tile(x + dx, y, z + dz) == 0;

	bool handled = false;
	if(couchDown) {
		offset(meta, DOWN, dx, dz);
		int r = rotationFor(meta, acc.data(x + dx, y, z + dz));
		if(r == RIGHT) {
			out[n++] = CouchBox{0.0f, 0.6f, 0.0f, 0.75f, 1.2f, 0.25f};
			handled = true;
		} else if(r == LEFT) {
			out[n++] = CouchBox{0.0f, 0.6f, 0.75f, 0.75f, 1.2f, 1.0f};
			handled = true;
		}
	}
	if(!handled) {
		if(airLeft) out[n++] = CouchBox{-0.001f, 0.5f, -0.2f, 1.001f, 0.9f, 0.05f};
		if(airRight) out[n++] = CouchBox{-0.001f, 0.5f, 0.95f, 1.001f, 0.9f, 1.2f};
	}

	out[n++] = CouchBox{0.75f, 0.6f, 0.0f, 1.0f, 1.2f, 1.0f}; // respaldo
	out[n++] = CouchBox{0.0f, 0.0f, 0.0f, 1.0f, 0.6f, 1.0f};  // base
	return n;
}

}
