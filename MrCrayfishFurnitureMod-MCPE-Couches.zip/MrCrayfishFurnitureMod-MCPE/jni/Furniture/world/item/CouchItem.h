#pragma once

#include "PlaceableItem.h"

class CouchItem : public PlaceableItem {
public:
	static int _whiteId;
	static int _greenId;
	static int _brownId;
	static int _redId;
	static int _blackId;

	CouchItem(int, std::string, int);
};
