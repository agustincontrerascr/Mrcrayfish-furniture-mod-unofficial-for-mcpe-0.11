#include "CouchItem.h"

int CouchItem::_whiteId = 471;
int CouchItem::_greenId = 472;
int CouchItem::_brownId = 473;
int CouchItem::_redId = 474;
int CouchItem::_blackId = 475;

CouchItem::CouchItem(int id, std::string name, int tileId) : PlaceableItem(id, tileId) {
	setNameID(name);
	setIcon(name, 0);
}
