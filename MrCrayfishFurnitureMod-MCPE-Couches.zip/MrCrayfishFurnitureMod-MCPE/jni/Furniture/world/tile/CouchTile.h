#pragma once

#include "RotatableTile.h"

class CouchTile : public RotatableTile {
public:
	static int _whiteId;
	static int _greenId;
	static int _brownId;
	static int _redId;
	static int _blackId;

	static bool isCouchId(int id);

	// woolIndex = color de lana (0 blanco, 13 verde, 12 cafe, 14 rojo, 15 negro)
	CouchTile(int, std::string, int, int);

	virtual const TextureUVCoordinateSet& getTexture(signed char, int);
	virtual int getResource(int, Random*);
	virtual bool use(Player*, int, int, int);
	virtual void addAABBs(TileSource*, int, int, int, AABB const*, std::vector<AABB, std::allocator<AABB>>&);

private:
	int droppedItem;
};
