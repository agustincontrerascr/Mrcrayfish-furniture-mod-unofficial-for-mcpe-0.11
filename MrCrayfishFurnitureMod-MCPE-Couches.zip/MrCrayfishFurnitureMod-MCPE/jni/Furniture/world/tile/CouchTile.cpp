#include "CouchTile.h"

#include "MCPE/world/material/Material.h"

int CouchTile::_whiteId = 211;
int CouchTile::_greenId = 212;
int CouchTile::_brownId = 213;
int CouchTile::_redId = 214;
int CouchTile::_blackId = 215;

bool CouchTile::isCouchId(int id) {
	return id == _whiteId || id == _greenId || id == _brownId || id == _redId || id == _blackId;
}

CouchTile::CouchTile(int id, std::string name, int woolIndex, int item) : RotatableTile(id, &Material::cloth) {
	Tile::solid[id] = false;
	Tile::lightBlock[id] = 0;

	setNameId(name);
	setSoundType(Tile::SOUND_CLOTH);
	setDestroyTime(0.8F);
	tex = getTextureUVCoordinateSet("wool", woolIndex);
	this->droppedItem = item;
}

const TextureUVCoordinateSet& CouchTile::getTexture(signed char side, int data) {
	return tex;
}

bool CouchTile::use(Player* player, int x, int y, int z) {
	return false;
}

int CouchTile::getResource(int data, Random* rand) {
	return droppedItem;
}

void CouchTile::addAABBs(TileSource* region, int x, int y, int z, AABB const* posAABB, std::vector<AABB, std::allocator<AABB>>& pool) {
	int data = region->getData(x, y, z);
	// Asiento
	addAABB(AABB(0.0F, 0.0F, 0.0F, 1.0F, 0.6F, 1.0F).move(x, y, z), posAABB, pool);
	// Respaldo
	addAABB(CollisionHelper::getRotatedCollisionBox(data, 0.75F, 0.6F, 0.0F, 1.0F, 1.2F, 1.0F).move(x, y, z), posAABB, pool);
}
