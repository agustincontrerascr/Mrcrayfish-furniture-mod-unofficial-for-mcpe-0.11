# Sofas (Couch) para MrCrayfish's Furniture Mod PE

Se añadieron 5 sofas: blanco, verde, cafe, rojo y negro.
Aparecen en el inventario creativo. Se orientan segun donde miras y se unen entre si
(esquinas y brazos), igual que en el script .js.

## Archivos nuevos
- jni/Furniture/world/tile/CouchTile.h/.cpp   (bloque, ids 211-215)
- jni/Furniture/world/item/CouchItem.h/.cpp   (items, ids 471-475)
- jni/Furniture/render/tile/CouchLogic.h      (logica de conexion, probada contra el JS)
- jni/Furniture/render/tile/renderers/CouchRenderer.h/.cpp

## Archivos modificados
- jni/Furniture_hooks.cpp (registro de tiles, items, renderers, nombres, creativo)
- jni/Furniture/world/tile/FurnitureTile.h/.cpp, jni/Furniture/world/item/FurnitureItem.h/.cpp
- jni/MCPE/world/entity/Motive.h  (faltaba declarar initCustomMotives(), error del proyecto original)
- assets/images/items.meta y items-opaque.png (5 iconos nuevos)

## Compilar (necesita Android NDK y Android SDK)
    cd MrCrayfishFurnitureMod-MCPE
    ndk-build            # genera libs/armeabi-v7a/libcom.mrcrayfish.furniturepe.so
    ant debug            # o empaquetalo con tu herramienta habitual (build.xml incluido)
Instala el APK resultante y activalo en BlockLauncher > Administrar addons.
Ojo: el AndroidManifest apunta a MCPE 0.11.0.
