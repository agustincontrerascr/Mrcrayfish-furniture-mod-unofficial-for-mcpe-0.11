#pragma once

#include <string>

// The blocks of MrCrayfishFurnitureModPE.js ported to native code.
namespace ExtraFurniture {
	bool isCoffeeTable(int tileId);
	bool isCouch(int tileId);
	bool isHedge(int tileId);

	void initTiles();
	void initItems();
	void initCreativeItems();
	void initRenderers();

	// Returns true and fills 'out' if the I18n key belongs to one of the extra items.
	bool getName(const std::string& key, std::string& out);
	// True if the tile is one of the extra tiles (used so water does not wash them away).
	bool isExtraTile(void* tile);
}
