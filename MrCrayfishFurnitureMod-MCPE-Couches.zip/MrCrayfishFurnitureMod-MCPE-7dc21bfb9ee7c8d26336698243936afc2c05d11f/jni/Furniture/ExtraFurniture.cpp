#include "ExtraFurniture.h"

#include <vector>

#include "MCPE/world/level/tile/Tile.h"
#include "MCPE/world/material/Material.h"
#include "MCPE/world/item/Item.h"

#include "world/tile/ExtraTile.h"
#include "world/item/ExtraItem.h"
#include "render/tile/RenderDispatcher.h"
#include "render/tile/renderers/CabinetRenderer.h"
#include "render/tile/renderers/ExtraRenderers.h"

namespace ExtraFurniture {

enum Kind { COFFEE, BEDSIDE, COUCH, OVEN, HOOD, HEDGE };

struct Def {
	Kind kind;
	int tileId;
	int itemId;
	const char* tileName;
	const char* itemName;   // I18n key is "item.<itemName>.name"
	const char* display;
	const char* icon;       // icon taken from items.meta
	int material;           // 0 wood, 1 stone, 2 cloth, 3 leaves, 4 metal
	float hardness;
	const char* tex1; int idx1;
	const char* tex2; int idx2;
	const char* tex3; int idx3;
};

// Ids: tiles 208, 209, 211-222 (210 was the toilet, removed). Items 480-493.
static const Def DEFS[] = {
	{COFFEE,  208, 480, "woodCoffeeTableTile",  "woodCoffeeTableItem",  "Wooden Coffee Table", "woodTableItem",       0, 1.0F, "planks", 0, "log", 0, "log", 0},
	{COFFEE,  209, 481, "stoneCoffeeTableTile", "stoneCoffeeTableItem", "Stone Coffee Table",  "stoneTableItem",      1, 1.5F, "stone", 0, "cobblestone", 0, "cobblestone", 0},
	{BEDSIDE, 211, 482, "bedsideCabinetTile",   "bedsideCabinetItem2",  "Bedside Cabinet",     "bedsideCabinetItem",  0, 1.0F, "planks", 2, "planks", 1, "iron_block", 0},
	{COUCH,   212, 483, "whiteCouchTile",       "whiteCouchItem",       "White Couch",         "woodChairItem",       2, 0.8F, "wool", 0,  "wool", 0,  "wool", 0},
	{COUCH,   213, 484, "greenCouchTile",       "greenCouchItem",       "Green Couch",         "woodChairItem",       2, 0.8F, "wool", 13, "wool", 13, "wool", 13},
	{COUCH,   214, 485, "brownCouchTile",       "brownCouchItem",       "Brown Couch",         "woodChairItem",       2, 0.8F, "wool", 12, "wool", 12, "wool", 12},
	{COUCH,   215, 486, "redCouchTile",         "redCouchItem",         "Red Couch",           "woodChairItem",       2, 0.8F, "wool", 14, "wool", 14, "wool", 14},
	{COUCH,   216, 487, "blackCouchTile",       "blackCouchItem",       "Black Couch",         "woodChairItem",       2, 0.8F, "wool", 15, "wool", 15, "wool", 15},
	{OVEN,    217, 488, "ovenTile",             "ovenItem2",            "Oven",                "binItem",             4, 2.0F, "quartz_block", 1, "quartz_block", 1, "quartz_block", 1},
	{HOOD,    218, 489, "ovenRangehoodTile",    "ovenRangehoodItem",    "Oven Rangehood",      "binItem",             4, 2.0F, "stone_slab", 0, "stone", 0, "glowstone", 0},
	{HEDGE,   219, 490, "oakHedgeTile",         "oakHedgeItem",         "Oak Hedge",           "lampItem",            3, 0.4F, "leaves", 4, "leaves", 4, "leaves", 4},
	{HEDGE,   220, 491, "spruceHedgeTile",      "spruceHedgeItem",      "Spruce Hedge",        "lampItem",            3, 0.4F, "leaves", 5, "leaves", 5, "leaves", 5},
	{HEDGE,   221, 492, "birchHedgeTile",       "birchHedgeItem",       "Birch Hedge",         "lampItem",            3, 0.4F, "leaves", 6, "leaves", 6, "leaves", 6},
	{HEDGE,   222, 493, "jungleHedgeTile",      "jungleHedgeItem",      "Jungle Hedge",        "lampItem",            3, 0.4F, "leaves", 7, "leaves", 7, "leaves", 7},
};
static const int DEF_COUNT = sizeof(DEFS) / sizeof(DEFS[0]);

static std::vector<ExtraTile*> tiles;
static std::vector<ExtraItem*> items;

static bool hasKind(int tileId, Kind kind) {
	for(int i = 0; i < DEF_COUNT; i++)
		if(DEFS[i].tileId == tileId) return DEFS[i].kind == kind;
	return false;
}

bool isCoffeeTable(int tileId) { return hasKind(tileId, COFFEE); }
bool isCouch(int tileId) { return hasKind(tileId, COUCH); }
bool isHedge(int tileId) { return hasKind(tileId, HEDGE); }

static Material* materialOf(int m) {
	switch(m) {
	case 0: return &Material::wood;
	case 1: return &Material::stone;
	case 2: return &Material::cloth;
	case 3: return &Material::leaves;
	default: return &Material::metal;
	}
}

static const Tile::SoundType& soundOf(int m) {
	switch(m) {
	case 0: return Tile::SOUND_WOOD;
	case 1: return Tile::SOUND_STONE;
	case 2: return Tile::SOUND_CLOTH;
	case 3: return Tile::SOUND_GRASS;
	default: return Tile::SOUND_METAL;
	}
}

void initTiles() {
	tiles.clear();
	for(int i = 0; i < DEF_COUNT; i++) {
		const Def& d = DEFS[i];
		tiles.push_back(new ExtraTile(d.tileId, d.tileName, materialOf(d.material), soundOf(d.material), d.hardness,
				d.itemId, d.tex1, d.idx1, d.tex2, d.idx2, d.tex3, d.idx3));
	}
}

void initItems() {
	items.clear();
	for(int i = 0; i < DEF_COUNT; i++) {
		const Def& d = DEFS[i];
		items.push_back(new ExtraItem(d.itemId, d.itemName, d.icon, d.tileId));
	}
}

void initCreativeItems() {
	for(unsigned i = 0; i < items.size(); i++)
		Item::addCreativeItem(items[i], 0);
}

void initRenderers() {
	for(int i = 0; i < DEF_COUNT; i++) {
		BlockRenderer* r = NULL;
		switch(DEFS[i].kind) {
		case COFFEE:  r = new CoffeeTableRenderer(); break;
		case BEDSIDE: r = new CabinetRenderer(); break;
		case COUCH:   r = new CouchRenderer(); break;
		case OVEN:    r = new OvenRenderer(); break;
		case HOOD:    r = new RangehoodRenderer(); break;
		case HEDGE:   r = new HedgeRenderer(); break;
		}
		RenderDispatcher::registerRenderer(DEFS[i].tileId, r);
	}
}

bool getName(const std::string& key, std::string& out) {
	for(int i = 0; i < DEF_COUNT; i++) {
		std::string k = std::string("item.") + DEFS[i].itemName + ".name";
		if(key == k) {
			out = DEFS[i].display;
			return true;
		}
	}
	return false;
}

bool isExtraTile(void* tile) {
	for(unsigned i = 0; i < tiles.size(); i++)
		if((void*) tiles[i] == tile) return true;
	return false;
}

}
