#pragma once

#include <string>

#include "PlaceableItem.h"

class ExtraItem : public PlaceableItem {
public:
	ExtraItem(int id, const std::string& nameId, const std::string& icon, int tileId);
};
