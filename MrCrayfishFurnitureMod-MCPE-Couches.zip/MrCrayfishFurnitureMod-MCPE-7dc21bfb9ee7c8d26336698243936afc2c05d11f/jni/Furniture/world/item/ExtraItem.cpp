#include "ExtraItem.h"

ExtraItem::ExtraItem(int id, const std::string& nameId, const std::string& icon, int tileId) : PlaceableItem(id, tileId) {
	setNameID(nameId);
	setIcon(icon, 0);
}
