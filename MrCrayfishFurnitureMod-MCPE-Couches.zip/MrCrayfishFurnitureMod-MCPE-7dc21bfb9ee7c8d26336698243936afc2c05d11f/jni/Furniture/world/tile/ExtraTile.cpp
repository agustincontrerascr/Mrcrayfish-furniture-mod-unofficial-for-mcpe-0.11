#include "ExtraTile.h"

ExtraTile::ExtraTile(int id, const std::string& nameId, Material const* material, const Tile::SoundType& sound, float hardness,
		int droppedItem, const char* tex1, int idx1, const char* tex2, int idx2, const char* tex3, int idx3)
		: RotatableTile(id, material) {
	Tile::solid[id] = false;
	Tile::lightBlock[id] = 0;

	setNameId(nameId);
	setSoundType(sound);
	setDestroyTime(hardness);

	tex = getTextureUVCoordinateSet(tex1, idx1);
	secondary_tex = getTextureUVCoordinateSet(tex2, idx2);
	terciary_tex = getTextureUVCoordinateSet(tex3, idx3);
	this->droppedItem = droppedItem;
}

const TextureUVCoordinateSet& ExtraTile::getTexture(signed char side, int data) {
	return side == 0 ? tex : (side == 1 ? secondary_tex : terciary_tex);
}

bool ExtraTile::use(Player* player, int x, int y, int z) {
	return false;
}

int ExtraTile::getResource(int data, Random* rand) {
	return droppedItem;
}
