#pragma once

#include <string>

#include "RotatableTile.h"

// Generic rotatable furniture tile used for the blocks ported from the ModPE (.js) version:
// coffee tables, bedside cabinet, couches, oven, oven rangehood and hedges.
class ExtraTile : public RotatableTile {
public:
	ExtraTile(int id, const std::string& nameId, Material const* material, const Tile::SoundType& sound, float hardness,
			int droppedItem, const char* tex1, int idx1, const char* tex2, int idx2, const char* tex3, int idx3);

	virtual const TextureUVCoordinateSet& getTexture(signed char, int);
	virtual int getResource(int, Random*);
	virtual bool use(Player*, int, int, int);

private:
	TextureUVCoordinateSet secondary_tex;
	TextureUVCoordinateSet terciary_tex;
	int droppedItem;
};
