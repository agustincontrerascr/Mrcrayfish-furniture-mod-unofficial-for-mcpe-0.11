#include "ExtraRenderers.h"

#include "../../../ExtraFurniture.h"

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

// Texture lookup with a cache (the atlas lookup is a string search, too slow to do per frame).
struct CachedTex {
	bool ready;
	TextureUVCoordinateSet uv;
	CachedTex() : ready(false) {}
};

static const TextureUVCoordinateSet& tex(CachedTex& c, FurnitureTile* tile, const char* name, int idx) {
	if(!c.ready) {
		c.uv = tile->getTextureUVCoordinateSet(name, idx);
		c.ready = true;
	}
	return c.uv;
}

static int tileAt(TileTessellator* tess, int x, int y, int z) {
	return tess->region->getTile(x, y, z).id;
}

// Draws a box with the given UV. If 'rotate' is true the box is rotated with the tile data (like the .js "useMetadata").
static void box(BlockRenderer* r, TileTessellator* tess, FurnitureTile* tile, const TilePos& pos, int data, bool rotate,
		float x1, float y1, float z1, float x2, float y2, float z2) {
	if(rotate)
		r->setRotatedBounds(tess, data, x1, y1, z1, x2, y2, z2);
	else
		tess->setRenderBounds(x1, y1, z1, x2, y2, z2);
	tess->tessellateBlockInWorld(tile, pos);
}

// ---------------------------------------------------------------------------
// Coffee table
// ---------------------------------------------------------------------------

void CoffeeTableRenderer::render(const TilePos& pos, FurnitureTile* tile, TileTessellator* tess) {
	int x = pos.x, y = pos.y, z = pos.z;
	bool forward = ExtraFurniture::isCoffeeTable(tileAt(tess, x + 1, y, z));
	bool back = ExtraFurniture::isCoffeeTable(tileAt(tess, x - 1, y, z));
	bool left = ExtraFurniture::isCoffeeTable(tileAt(tess, x, y, z - 1));
	bool right = ExtraFurniture::isCoffeeTable(tileAt(tess, x, y, z + 1));

	tess->useForcedUV = true;
	tess->forcedUV = tile->getTexture(0, 0);

	// Table top
	box(this, tess, tile, pos, 0, false, 0.0F, 0.4F, 0.0F, 1.0F, 0.5F, 1.0F);

	// Legs (only at the outer corners of a row of tables)
	if(!back && !left)    box(this, tess, tile, pos, 0, false, 0.0F, 0.0F, 0.0F, 0.1F, 0.4F, 0.1F);
	if(!back && !right)   box(this, tess, tile, pos, 0, false, 0.0F, 0.0F, 0.9F, 0.1F, 0.4F, 1.0F);
	if(!forward && !left) box(this, tess, tile, pos, 0, false, 0.9F, 0.0F, 0.0F, 1.0F, 0.4F, 0.1F);
	if(!forward && !right) box(this, tess, tile, pos, 0, false, 0.9F, 0.0F, 0.9F, 1.0F, 0.4F, 1.0F);

	tess->useForcedUV = false;
}

// ---------------------------------------------------------------------------
// Couch
// ---------------------------------------------------------------------------

enum { C_UP = 0, C_DOWN = 1, C_LEFT = 2, C_RIGHT = 3 };

// Neighbour position of a couch with rotation 'meta' in direction 'dir' (same table as the .js version).
static void couchNeighbour(int x, int z, int meta, int dir, int& nx, int& nz) {
	nx = x; nz = z;
	switch(dir) {
	case C_UP:
		if(meta == 3) nx = x + 1; else if(meta == 1) nx = x - 1; else if(meta == 2) nz = z - 1; else nz = z + 1;
		break;
	case C_DOWN:
		if(meta == 3) nx = x - 1; else if(meta == 1) nx = x + 1; else if(meta == 2) nz = z + 1; else nz = z - 1;
		break;
	case C_LEFT:
		if(meta == 2) nx = x - 1; else if(meta == 0) nx = x + 1; else if(meta == 3) nz = z - 1; else nz = z + 1;
		break;
	case C_RIGHT:
		if(meta == 2) nx = x + 1; else if(meta == 0) nx = x - 1; else if(meta == 3) nz = z + 1; else nz = z - 1;
		break;
	}
}

static int couchRotation(int meta, int blockMeta) {
	static const int table[4][4] = {
		// blockMeta:   0        1        2        3
		/* meta 0 */ { C_DOWN,  C_LEFT,  C_UP,    C_RIGHT },
		/* meta 1 */ { C_RIGHT, C_DOWN,  C_LEFT,  C_UP    },
		/* meta 2 */ { C_UP,    C_RIGHT, C_DOWN,  C_LEFT  },
		/* meta 3 */ { C_LEFT,  C_UP,    C_RIGHT, C_DOWN  },
	};
	return table[meta & 3][blockMeta & 3];
}

void CouchRenderer::render(const TilePos& pos, FurnitureTile* tile, TileTessellator* tess) {
	int x = pos.x, y = pos.y, z = pos.z;
	int meta = tess->region->getData(x, y, z) & 3;

	tess->useForcedUV = true;
	tess->forcedUV = tile->getTexture(0, 0);

	int nx, nz;
	couchNeighbour(x, z, meta, C_DOWN, nx, nz);
	bool downIsCouch = ExtraFurniture::isCouch(tileAt(tess, nx, y, nz));

	couchNeighbour(x, z, meta, C_LEFT, nx, nz);
	bool airLeft = tileAt(tess, nx, y, nz) == 0;
	couchNeighbour(x, z, meta, C_RIGHT, nx, nz);
	bool airRight = tileAt(tess, nx, y, nz) == 0;

	bool armrests = true;
	if(downIsCouch) {
		couchNeighbour(x, z, meta, C_DOWN, nx, nz);
		int rot = couchRotation(meta, tess->region->getData(nx, y, nz));
		if(rot == C_RIGHT) {
			box(this, tess, tile, pos, meta, true, 0.0F, 0.6F, 0.0F, 0.75F, 1.2F, 0.25F);
			armrests = false;
		} else if(rot == C_LEFT) {
			box(this, tess, tile, pos, meta, true, 0.0F, 0.6F, 0.75F, 0.75F, 1.2F, 1.0F);
			armrests = false;
		}
	}
	if(armrests) {
		if(airLeft)  box(this, tess, tile, pos, meta, true, -0.001F, 0.5F, -0.2F, 1.001F, 0.9F, 0.05F);
		if(airRight) box(this, tess, tile, pos, meta, true, -0.001F, 0.5F, 0.95F, 1.001F, 0.9F, 1.2F);
	}

	// Back rest and seat
	box(this, tess, tile, pos, meta, true, 0.75F, 0.6F, 0.0F, 1.0F, 1.2F, 1.0F);
	box(this, tess, tile, pos, 0, false, 0.0F, 0.0F, 0.0F, 1.0F, 0.6F, 1.0F);

	tess->useForcedUV = false;
}

// ---------------------------------------------------------------------------
// Oven
// ---------------------------------------------------------------------------

void OvenRenderer::render(const TilePos& pos, FurnitureTile* tile, TileTessellator* tess) {
	static CachedTex quartz, obsidian, stone;
	int data = tess->region->getData(pos.x, pos.y, pos.z) & 3;

	tess->useForcedUV = true;

	// Base
	tess->forcedUV = tex(quartz, tile, "quartz_block", 1);
	box(this, tess, tile, pos, 0, false, 0.0625F, 0.0F, 0.0625F, 0.9375F, 1.0F, 0.9375F);

	// Stove top
	tess->forcedUV = tex(obsidian, tile, "obsidian", 0);
	box(this, tess, tile, pos, 0, false, 0.1875F, 0.5F, 0.1875F, 0.4325F, 1.0625F, 0.4375F);
	box(this, tess, tile, pos, 0, false, 0.1875F, 0.5F, 0.5625F, 0.4325F, 1.0625F, 0.8125F);
	box(this, tess, tile, pos, 0, false, 0.5625F, 0.5F, 0.1875F, 0.8125F, 1.0625F, 0.4375F);
	box(this, tess, tile, pos, 0, false, 0.5625F, 0.5F, 0.5625F, 0.8125F, 1.0625F, 0.8125F);

	// Back piece
	tess->forcedUV = tex(quartz, tile, "quartz_block", 1);
	box(this, tess, tile, pos, data, true, 0.875F, 0.0F, 0.0624F, 1.0F, 1.1875F, 0.9376F);

	// Door
	tess->forcedUV = tex(stone, tile, "stone", 0);
	box(this, tess, tile, pos, data, true, 0.0F, 0.2F, 0.2F, 0.0625F, 0.8125F, 0.8F);

	tess->useForcedUV = false;
}

// ---------------------------------------------------------------------------
// Oven rangehood
// ---------------------------------------------------------------------------

void RangehoodRenderer::render(const TilePos& pos, FurnitureTile* tile, TileTessellator* tess) {
	static CachedTex slab, stone, glow, obsidian;
	int data = tess->region->getData(pos.x, pos.y, pos.z) & 3;

	tess->useForcedUV = true;

	// Vent base
	tess->forcedUV = tex(slab, tile, "stone_slab", 0);
	box(this, tess, tile, pos, 0, false, 0.0F, 0.025F, 0.0F, 1.0F, 0.2F, 1.0F);

	// Vent top
	tess->forcedUV = tex(stone, tile, "stone", 0);
	box(this, tess, tile, pos, 0, false, 0.0F, 0.2F, 0.0F, 1.0F, 0.25F, 1.0F);

	// Tunnel
	tess->forcedUV = tex(glow, tile, "glowstone", 0);
	box(this, tess, tile, pos, data, true, 0.5F, 0.2F, 0.2F, 1.0F, 1.0F, 0.8F);

	// Light
	tess->forcedUV = tex(obsidian, tile, "obsidian", 0);
	box(this, tess, tile, pos, 0, false, 0.1F, 0.0F, 0.1F, 0.9F, 0.05F, 0.9F);

	tess->useForcedUV = false;
}

// ---------------------------------------------------------------------------
// Hedge
// ---------------------------------------------------------------------------

void HedgeRenderer::render(const TilePos& pos, FurnitureTile* tile, TileTessellator* tess) {
	int x = pos.x, y = pos.y, z = pos.z;

	tess->useForcedUV = true;
	tess->forcedUV = tile->getTexture(0, 0);

	// Base
	box(this, tess, tile, pos, 0, false, 0.1875F, 0.0F, 0.1875F, 0.8125F, 1.0F, 0.8125F);

	// Sides towards neighbouring hedges
	if(ExtraFurniture::isHedge(tileAt(tess, x + 1, y, z))) box(this, tess, tile, pos, 0, false, 0.8125F, 0.0F, 0.1875F, 1.0F, 1.0F, 0.8125F);
	if(ExtraFurniture::isHedge(tileAt(tess, x - 1, y, z))) box(this, tess, tile, pos, 0, false, 0.0F, 0.0F, 0.1875F, 0.1875F, 1.0F, 0.8125F);
	if(ExtraFurniture::isHedge(tileAt(tess, x, y, z + 1))) box(this, tess, tile, pos, 0, false, 0.1875F, 0.0F, 0.8125F, 0.8125F, 1.0F, 1.0F);
	if(ExtraFurniture::isHedge(tileAt(tess, x, y, z - 1))) box(this, tess, tile, pos, 0, false, 0.1875F, 0.0F, 0.0F, 0.8125F, 1.0F, 0.1875F);

	tess->useForcedUV = false;
}
