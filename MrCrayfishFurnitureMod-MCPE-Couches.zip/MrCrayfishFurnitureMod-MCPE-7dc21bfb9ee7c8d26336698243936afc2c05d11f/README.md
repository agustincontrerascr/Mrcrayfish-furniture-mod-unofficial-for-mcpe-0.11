# MrCrayfishFurnitureMod-MCPE
MrCrayfish's Furniture Mod  - Now for MCPE!

## Bloques del .js portados a nativo (ExtraFurniture)
Se eliminaron del registro el inodoro, el timbre y el cubo de basura del v4 original
(las clases siguen en el codigo; para recuperarlos revierte los cambios en `Furniture_hooks.cpp`).
Se anadieron en `jni/Furniture/ExtraFurniture.cpp` los bloques del .js que faltaban:
mesas de centro (madera/piedra), mesita de noche, 5 sofas (blanco, verde, marron, rojo, negro),
horno, campana del horno y 4 setos (roble, abeto, abedul, jungla).
Junto con silla/mesa de madera y piedra, armario y lampara ya existentes, son los 20 bloques del .js.
Los iconos de items son provisionales (reutilizan iconos existentes de items.meta).
Compilar: `ndk-build` en la carpeta del proyecto, luego firmar el APK.
